package com.cap.foreign;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dept1")
public class Department {
	@Id
	@GeneratedValue
	@Column(length=10)
	private long deptNo;
	@Column(length=10)
	private String dname;
	@Column(length=10)
	private String dloc;
	public long getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(long deptNo) {
		this.deptNo = deptNo;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDloc() {
		return dloc;
	}
	public void setDloc(String dloc) {
		this.dloc = dloc;
	}

}

package com.cap.foreign;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name="emp1")
public class Employee {
	@Id
	@GeneratedValue
	@Column(length=10)
	private int eid;
	@Column(length=10)
	private String ename;
	@Column(length=10)
	private String eaddress;
	@Column(length=10)
	private int esal;
	
	@ManyToOne
	@OnDelete(action=OnDeleteAction.CASCADE)
		
	private Department dept;
	public Employee(){
	
	}
	public Employee(String ename, String eaddress, int esal, Department dept) {
		super();
		this.ename = ename;
		this.eaddress = eaddress;
		this.esal = esal;
		this.dept = dept;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEaddress() {
		return eaddress;
	}
	public void setEaddress(String eaddress) {
		this.eaddress = eaddress;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}

}

package com.cap.foreign;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
	public static void main(String[] args) {
		EntityManagerFactory emfactory=Persistence.createEntityManagerFactory("jaga");
		EntityManager entityManager=emfactory.createEntityManager();
		entityManager.getTransaction().begin();
		
		Department department=new Department();
		department.setDname("Deve");
		department.setDloc("Cbe");
		entityManager.persist(department);
Employee employee=new Employee("suresh","bangalore",1200,department);
Employee employee1=new Employee("ramesh","chennai",1300,department);
Employee employee2=new Employee("rakesh","hydrabad",1400,department);
entityManager.persist(employee);
entityManager.persist(employee1);
entityManager.persist(employee2);
entityManager.getTransaction().commit();



	
	}

}

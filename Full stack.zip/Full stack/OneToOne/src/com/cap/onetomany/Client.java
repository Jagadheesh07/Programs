package com.cap.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("jaga");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		
		Address ad1=new Address();
		ad1.setHno(123);
		ad1.setColony("PKS Nagar");
		ad1.setCity("cbe");
		//em.persist(ad1);
		
		Employee emp=new Employee();
		
		emp.setEname("chandhru");
		emp.setEsal(2000);
		emp.setAdt(ad1);	
		em.persist(emp);
		
		em.getTransaction().commit();
		em.close();
		factory.close();
		
	}

}

package com.cap.exception;
//user defined exception

public class AmountExceedException extends RuntimeException {

	public AmountExceedException(String msg) {
		super(msg);
		
	}

}

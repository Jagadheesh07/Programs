package com.cap.exception;

//user defined exception

public class InputMismatchException extends RuntimeException  {

	public InputMismatchException(String msg) {
		super(msg);

	}
	

}

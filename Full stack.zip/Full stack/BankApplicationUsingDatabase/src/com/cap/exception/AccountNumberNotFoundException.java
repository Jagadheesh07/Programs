package com.cap.exception;
//user defined exception
@SuppressWarnings("serial")
public class AccountNumberNotFoundException extends RuntimeException {
	public AccountNumberNotFoundException(final String msg) {
		super(msg);
	}

}

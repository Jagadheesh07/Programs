package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cap.bean.Bank;
import com.cap.bean.Transaction;

public class BankDaoImpl implements BankDao {
	Connection conn = DBConnect.getConnection();

	//CreateAccount
	@Override
	public long insertCreateAccount(Bank bank) {
		long accountNo = 0;

		try {

			PreparedStatement stat = conn.prepareStatement("insert into bank values(sampleseq.nextval,?,?,?,?,?)");
			stat.setString(1, bank.getAccHolderName());
			stat.setString(2, bank.getBranch());
			stat.setLong(3, bank.getmobileNo());
			stat.setString(4, bank.getAccType());
			stat.setLong(5, bank.getBalance());
			int result = stat.executeUpdate();
			if (result > 0) {
				PreparedStatement Stat = conn.prepareStatement("select sampleseq.currVal from dual");
				ResultSet rslt = Stat.executeQuery();
				rslt.next();
				accountNo = rslt.getLong(1);

				System.out.println("Successfully Registered ");
			} else {
				System.out.println("Registered Failed");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accountNo;
	}

	// TODO Auto-generated method stub

	//ShowingAvailabeBlaance
	@Override
	public long retriveShowBalance(Long accountNo1) {

		long accountNo = 0;
		try {
			PreparedStatement Stat = conn.prepareStatement("select Balance from bank where accountNo=?");
			Stat.setLong(1, accountNo1);
			ResultSet val = Stat.executeQuery();
			val.next();
			accountNo = val.getLong(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accountNo;
	}

	//Deposite
	@Override
	public long deposit(Long accountNo2, Long depositAmount) {
		long deposit = 0;
		try {
			PreparedStatement Stat = conn.prepareStatement("select Balance from bank where accountNo=?");
			Stat.setLong(1, accountNo2);
			ResultSet val = Stat.executeQuery();
			val.next();
			long previous = val.getLong(1);
			deposit = previous + depositAmount;
			PreparedStatement Stat1 = conn.prepareStatement("update bank set Balance=? where accountNo=? ");
			Stat1.setLong(1, deposit);
			Stat1.setLong(2, accountNo2);
			int value1=Stat1.executeUpdate();
			if(value1>0)
			{	
				PreparedStatement trn=conn.prepareStatement("insert into trans values(sampleseq.nextVal,?,?,?,?,?)");
				trn.setLong(1,accountNo2);
				trn.setLong(2,accountNo2);
				trn.setLong(3,previous);
				trn.setLong(4,deposit);
				trn.setString(5,"Deposite");
				trn.executeUpdate();
				
		}
			else{
				System.out.println("There is no any transaction");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return deposit;
	}

	//Withdraw
	@Override
	public long withdraw(Long accountNo3, Long withdrawAmount) {
		long withdraw = 0;
		try {
			PreparedStatement Stat = conn.prepareStatement("select Balance from bank where accountNo=?");
			Stat.setLong(1, accountNo3);
			ResultSet val2 = Stat.executeQuery();
			val2.next();
			long previous = val2.getLong(1);
			withdraw = previous - withdrawAmount;
			PreparedStatement Stat1 = conn.prepareStatement("update bank  set Balance=? where accountNo=?");
			Stat1.setLong(1, withdraw);
			Stat1.setLong(2, accountNo3);
			Stat1.executeUpdate();
			int value1=Stat1.executeUpdate();
			if(value1>0)
			{	
				PreparedStatement trn=conn.prepareStatement("insert into trans values(sampleseq.nextVal,?,?,?,?,?)");
				trn.setLong(1,accountNo3);
				trn.setLong(2,accountNo3);
				trn.setLong(3,previous);
				trn.setLong(4,withdraw);
				trn.setString(5,"Withdraw");
				trn.executeUpdate();
				
		}
			else{
				System.out.println("There is no any transaction");
		}} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return withdraw;
	}
	
	//FundTransfer

	@Override
	public long fundTransfer(Long accountNo4, Long accountNo5, Long transferAmount) {
		long Balance = 0;
		long Balance1 = 0;
		try {
			conn=DBConnect.getConnection();
			PreparedStatement Stat = conn.prepareStatement("select Balance from bank where accountNo=?");
			Stat.setLong(1, accountNo4);
			ResultSet val3 = Stat.executeQuery();
			val3.next();
			long previous = val3.getLong(1);
			Balance = previous - transferAmount;
			PreparedStatement Stat2 = conn.prepareStatement("update bank  set Balance=? where accountNo=?");
			Stat2.setLong(1, Balance);
			Stat2.setLong(2, accountNo4);
			Stat2.executeUpdate();
			int value1=Stat2.executeUpdate();
			if(value1>0)
			{	
				PreparedStatement trn=conn.prepareStatement("insert into trans values(sampleseq.nextVal,?,?,?,?,?)");
				trn.setLong(1,accountNo4);
				trn.setLong(2,accountNo5);
				trn.setLong(3,previous);
				trn.setLong(4,Balance);
				trn.setString(5,"FundTransfer");
				trn.executeUpdate();
				
		}
	
			
			PreparedStatement Stat1 = conn.prepareStatement("select Balance from bank where accountNo=?");
			Stat1.setLong(1, accountNo5);
			ResultSet val4 = Stat1.executeQuery();
			val4.next();
			long previous1 = val4.getLong(1);
			Balance1 = previous1 + transferAmount;
			PreparedStatement Stat3 = conn.prepareStatement("update bank  set Balance=? where accountNo=?");
			
			Stat3.setLong(1, Balance1);
			Stat3.setLong(2, accountNo5);
			
			int value2=Stat3.executeUpdate();
			if(value2>0)
			{

				PreparedStatement trn=conn.prepareStatement("insert into trans values(sampleseq.nextVal,?,?,?,?,?)");
				trn.setLong(1,accountNo4);
				trn.setLong(2,accountNo5);
				trn.setLong(3,previous1);
				trn.setLong(4,Balance1);
				trn.setString(5,"FundTransfer");
				trn.executeUpdate();
				
		}
			else{
				System.out.println("There is no any transaction");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return Balance;
	}

	//PrintTransaction
	@Override
	public void printTransaction() {
		Transaction trs=new Transaction();
		PreparedStatement prs;
		try{
			prs=conn.prepareStatement("select * from trans");
			ResultSet rst=prs.executeQuery();
			while(rst.next())
			{
				int tId=rst.getInt(1);
				long fromAccount=rst.getLong(2);
				long toAccount=rst.getLong(3);
				long oldBalance=rst.getLong(4);
				long newBalance=rst.getLong(5);
				String transactionType=rst.getString(6);
				trs.setTid(tId);
				trs.setFromAccount(fromAccount);
				trs.setToAccount(toAccount);
				trs.setOldBalance(oldBalance);
				trs.setNewBAlance(newBalance);
				trs.setTranscationType(transactionType);
				System.out.println(trs);
				
						
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		
	}
}

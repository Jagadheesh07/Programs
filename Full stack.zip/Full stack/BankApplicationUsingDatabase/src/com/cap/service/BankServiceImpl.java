package com.cap.service;

import java.util.List;

import com.cap.bean.Bank;
import com.cap.bean.Transaction;
import com.cap.dao.BankDao;
import com.cap.dao.BankDaoImpl;
//implementation
public class BankServiceImpl implements BankService {
	BankDao dao = new BankDaoImpl();
	Bank bk = new Bank();

//ShowingAvailableBalance
	@Override
	public long retriveShowBalance(Long accountNo1) {
		return dao.retriveShowBalance(accountNo1);
		
	}

	//Deposite
	@Override
	public long deposit(Long accountNo2, Long depositeAmount) {
		long bk1 = dao.deposit(accountNo2, depositeAmount);
		return bk1;
	}

	//Withdraw
	@Override
	public long withdraw(Long accountNo3, Long withdrawAmount) {
		long bk1 = dao.withdraw(accountNo3, withdrawAmount);
		return bk1;
	}

	//FundTransfer
	@Override
	public long fundTransfer(Long accountNo4, Long accountNo5, Long transferAmount) {
		long bk1 = dao.fundTransfer(accountNo4, accountNo5, transferAmount);
		return bk1;

	}

	//PrintTransaction
	@Override
	public void printTransaction() {
	dao.printTransaction();
		
	}

	//Namevalidation
	@Override
	public boolean validateName(String accHolderName) {
		if (accHolderName.matches("[A-Z][a-zA-Z]*")) {
			return true;
		} else {
			return false;
		}

	}

	//MobileNumbervalidation
	@Override
	public boolean validateMobileNo(Long mobileNo) {
		String mobileno = Long.toString(mobileNo);
		if (mobileno.matches("[6-9][0-9]{9}")) {
			return true;
		} else {
			return false;
		}
	}

	//Accounttypevalidation
	@Override
	public boolean validateaccType(String accType) {
		if (accType.equalsIgnoreCase("savings") || (accType.equalsIgnoreCase("current")))

		{
			return true;
		} else {
			return false;
		}
	}

	//CreateAccount
	@Override
	public long insertCreateAccount(Bank bank) {
		return dao.insertCreateAccount(bank);
	}

}

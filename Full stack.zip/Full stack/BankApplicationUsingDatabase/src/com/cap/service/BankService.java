package com.cap.service;

import java.util.List;

import com.cap.bean.Bank;
import com.cap.bean.Transaction;

public interface BankService {
	long insertCreateAccount(Bank bank);

	long retriveShowBalance(Long accountNo1);

	long deposit(Long accountNo2, Long depositeAmount);

	long withdraw(Long accountNo3, Long withdrawAmount);

	long fundTransfer(Long accountNo4, Long accountNo5, Long transferAmount);

	void printTransaction();

	boolean validateName(String accHolderName);

	boolean validateMobileNo(Long mobileNo);

	boolean validateaccType(String accType);
}

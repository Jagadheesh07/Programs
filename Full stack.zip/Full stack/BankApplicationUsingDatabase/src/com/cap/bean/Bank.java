package com.cap.bean;

public class Bank {
	
	//Using toString method
	@Override
	public String toString() {
		return "Bank [accountNo=" + accountNo + ", accHolderName=" + accHolderName + ", branch=" + branch
				+ ", mobileNo=" + mobileNo + ", accType=" + accType + ", balance=" + balance + "]";
	}

	private long accountNo;
	private String accHolderName;
	private String branch;
	private long mobileNo;
	private String accType;
	private long balance;

	//Using Getters&Setters
	public long getAccountno() {
		return accountNo;
	}

	public void setAccountno(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public long getmobileNo() {
		return mobileNo;
	}

	public void setmobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}
}
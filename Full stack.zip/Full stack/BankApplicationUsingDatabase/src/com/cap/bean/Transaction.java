package com.cap.bean;

public class Transaction {
	private int tId;
	private long fromAccount;
	private long toAccount;
	private long oldBalance;
	private long newBalance;
	private String transcationType;

	@Override//using to string method
	public String toString() {
		return "Transaction [tid=" + tId + ", fromAccount=" + fromAccount + ", toAccount=" + toAccount + ", oldBalance="
				+ oldBalance + ", newBAlance=" + newBalance + ", transcationType=" + transcationType + "]";
	}
//Using getters and setters
	public int gettId() {
		return tId;
	}

	public void setTid(int tId) {
		this.tId = tId;
	}

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public long getToAccount() {
		return toAccount;
	}

	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}

	public long getOldBalance() {
		return oldBalance;
	}

	public void setOldBalance(long oldBalance) {
		this.oldBalance = oldBalance;
	}

	public long getNewBAlance() {
		return newBalance;
	}

	public void setNewBAlance(long newBAlance) {
		this.newBalance = newBAlance;
	}

	public String getTranscationType() {
		return transcationType;
	}

	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}

}

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="vendor1")
public class Vendor {
	@Id
	@Column(length=10)

	private int vid;
	@Column(length=10)
	private String vname;
	
	@OneToMany(targetEntity=Customer.class,cascade=CascadeType.ALL)
	@JoinColumn(name="venid",referencedColumnName="vid")
	private Set children;
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public Set getChildren() {
		return children;
	}
	public void setChildren(Set children) {
		this.children = children;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	

}

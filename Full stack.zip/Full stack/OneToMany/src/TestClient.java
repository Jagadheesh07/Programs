import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestClient {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jaga");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
		Vendor v=new  Vendor();
		v.setVid(123);
		v.setVname("alchemy");
		
		Customer c=new Customer();
		c.setCustid(124);
		c.setCustname("ibm");
		
		Customer c1=new Customer();
		c1.setCustid(125);
		c1.setCustname("capgemini");
		
		Set s=new HashSet();
		s.add(c);
		s.add(c1);
		v.setChildren(s);
		em.persist(v);
		em.getTransaction().commit();
	}

}

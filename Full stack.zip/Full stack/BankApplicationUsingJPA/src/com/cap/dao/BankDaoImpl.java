package com.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cap.entity.Bank;
import com.cap.entity.Transaction;

@Repository
public class BankDaoImpl implements BankDao {

	@PersistenceContext
	private EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Transactional
	@Override
	public long insertCreateAccount(Bank bank) {
		entityManager.persist(bank);
		return bank.getAccountno();
	}

	// TODO Auto-generated method stub

	@Override
	public long retriveShowBalance(Long accountNo1) {

		Bank b = entityManager.find(Bank.class, accountNo1);
		return b.getBalance();
	}

	@Transactional
	@Override

	public long deposit(Long accountNo2, Long depositAmount) {
		Bank b = entityManager.find(Bank.class, accountNo2);
		long oldbalance = b.getBalance();
		long newbalance = oldbalance + depositAmount;
		b.setBalance(newbalance);
		entityManager.merge(b);

		Transaction tr = new Transaction();
		tr.setFromAccount(accountNo2);
		tr.setToAccount(accountNo2);
		tr.setOldBalance(oldbalance);
		tr.setNewBAlance(newbalance);
		tr.setTranscationType("deposite");
		entityManager.persist(tr);

		return newbalance;
	}
@Transactional
	@Override
	public long withdraw(Long accountNo3, Long withdrawAmount) {
		Bank ba = entityManager.find(Bank.class, accountNo3);
		long oldbalance = ba.getBalance();
		long newbalance = oldbalance - withdrawAmount;
		ba.setBalance(newbalance);
		entityManager.merge(ba);

		Transaction tr = new Transaction();
		tr.setFromAccount(accountNo3);
		tr.setToAccount(accountNo3);
		tr.setOldBalance(oldbalance);
		tr.setNewBAlance(newbalance);
		tr.setTranscationType("Withdraw");
		entityManager.persist(tr);

		return newbalance;
	}
@Transactional
	@Override
	public long fundTransfer(Long accountNo4, Long accountNo5, Long transferAmount) {
		Bank b = entityManager.find(Bank.class, accountNo4);
		long oldbalance = b.getBalance();
		long newbalance = oldbalance - transferAmount;
		b.setBalance(newbalance);
		entityManager.merge(b);
		Transaction tr = new Transaction();
		tr.setFromAccount(accountNo4);
		tr.setToAccount(accountNo5);
		tr.setOldBalance(oldbalance);
		tr.setNewBAlance(newbalance);
		tr.setTranscationType("Fdtransfer");
		entityManager.persist(tr);
		Bank ba = entityManager.find(Bank.class, accountNo5);
		long oldbalance1 = ba.getBalance();
		long newbalance1 = oldbalance1 + transferAmount;
		ba.setBalance(newbalance);
		entityManager.merge(ba);
		Transaction tr1 = new Transaction();
		tr1.setFromAccount(accountNo4);
		tr1.setToAccount(accountNo5);
		tr1.setOldBalance(oldbalance1);
		tr1.setNewBAlance(newbalance1);
		tr1.setTranscationType("Fdtransfer");
		entityManager.persist(tr1);
		return newbalance;

	}

	@Override
	public List<Transaction> printTransaction() {
		TypedQuery<Transaction> q2 = entityManager.createQuery("select c from Transaction c", Transaction.class);
		List<Transaction> l1 = q2.getResultList();

		return l1;

		// TODO Auto-generated method stub

	}

}

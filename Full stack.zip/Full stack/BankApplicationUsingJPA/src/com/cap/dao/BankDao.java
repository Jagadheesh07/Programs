package com.cap.dao;

import java.util.List;

import com.cap.entity.Bank;
import com.cap.entity.Transaction;

public interface BankDao {
	long insertCreateAccount(Bank bank);

	long retriveShowBalance(Long accountNo1);

	long deposit(Long accountNo2, Long depositAmount);

	long withdraw(Long accountNo3, Long withdrawAmount);

	long fundTransfer(Long accountNo4, Long accountNo5, Long transferAmount);
	
	List<Transaction> printTransaction();

}

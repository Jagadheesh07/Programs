package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.BankDao;
import com.cap.dao.BankDaoImpl;
import com.cap.entity.Bank;
import com.cap.entity.Transaction;

//implementation
@Service("service")
public class BankServiceImpl implements BankService {
	
	private BankDao dao;
@Autowired
	public void setDao(BankDao dao) {
		this.dao = dao;
	}

	@Override
	public long retriveShowBalance(Long accountNo1) {
		return dao.retriveShowBalance(accountNo1);

	}

	@Override
	public long deposit(Long accountNo2, Long depositeAmount) {

		long bal = dao.deposit(accountNo2, depositeAmount);

		return bal;

	}

	@Override
	public long withdraw(Long accountNo3, Long withdrawAmount) {

		long bal = dao.withdraw(accountNo3, withdrawAmount);

		return bal;
	}

	@Override
	public long fundTransfer(Long accountNo4, Long accountNo5, Long transferAmount) {

		long bk1 = dao.fundTransfer(accountNo4, accountNo5, transferAmount);

		return bk1;

	}

	@Override
	public List<Transaction> printTransaction() {

		return dao.printTransaction();
	}

	@Override
	public boolean validateName(String accHolderName) {
		if (accHolderName.matches("[A-Z][a-zA-Z]*")) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public boolean validateMobileNo(Long mobileNo) {
		String mobileno = Long.toString(mobileNo);
		if (mobileno.matches("[6-9][0-9]{9}")) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validateaccType(String accType) {
		if (accType.equalsIgnoreCase("savings") || (accType.equalsIgnoreCase("current")))

		{
			return true;
		} else {
			return false;
		}
	}

	@Override
	public long insertCreateAccount(Bank bank) {
		return dao.insertCreateAccount(bank);

	}

}

package com.cap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Bank")
public class Bank {
	@Override
	public String toString() {
		return "Bank [accountNo=" + accountNo + ", accHolderName=" + accHolderName + ", branch=" + branch
				+ ", mobileNo=" + mobileNo + ", accType=" + accType + ", balance=" + balance + "]";
	}
@Id
@Column(name="AccountNum",length=10)
@GeneratedValue
	private long accountNo;
@Column(name="HolderName",length=10)
	private String accHolderName;
@Column(name="Branch",length=10)
	private String branch;
@Column(name="Mobileno",length=10)
	private long mobileNo;
@Column(name="AccountType",length=10)
	private String accType;
@Column(name="Balance",length=10)
	private long balance;

	public long getAccountno() {
		return accountNo;
	}

	public void setAccountno(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public long getmobileNo() {
		return mobileNo;
	}

	public void setmobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}
}
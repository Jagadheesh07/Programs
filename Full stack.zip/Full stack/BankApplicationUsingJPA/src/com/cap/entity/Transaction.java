package com.cap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Trans1")

public class Transaction {
	@Id
	@Column(name="TID",length=10)
	@GeneratedValue
	private int tId;
	@Column(name="FromAccount",length=10)
	private long fromAccount;
	@Column(name="TOAccount",length=10)
	private long toAccount;
	@Column(name="OldBalance",length=10)
	private long oldBalance;
	@Column(name="NewBalance",length=10)
	private long newBalance;
	@Column(name="TransactionType",length=10)
	private String transcationType;

	@Override//using to string method
	public String toString() {
		return "Transaction [tid=" + tId + ", fromAccount=" + fromAccount + ", toAccount=" + toAccount + ", oldBalance="
				+ oldBalance + ", newBAlance=" + newBalance + ", transcationType=" + transcationType + "]";
	}
//Using getters and setters
	public int gettId() {
		return tId;
	}

	public void setTid(int tId) {
		this.tId = tId;
	}

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public long getToAccount() {
		return toAccount;
	}

	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}

	public long getOldBalance() {
		return oldBalance;
	}

	public void setOldBalance(long oldBalance) {
		this.oldBalance = oldBalance;
	}

	public long getNewBAlance() {
		return newBalance;
	}

	public void setNewBAlance(long newBAlance) {
		this.newBalance = newBAlance;
	}

	public String getTranscationType() {
		return transcationType;
	}

	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}

}

package com.cap.ui;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cap.entity.Bank;
import com.cap.entity.Transaction;
import com.cap.exception.AccountNumberNotFoundException;
import com.cap.exception.AmountExceedException;
import com.cap.service.BankService;
import com.cap.service.BankServiceImpl;

public class Mainui {
	
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {

		while (true) {
			ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
			BankService service= ctx.getBean("service",BankServiceImpl.class);

			System.out.println("Welcome to bank application");
			System.out.println("enter your choice");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposite");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transaction");
			System.out.println("6.Print Transaction");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				// create Account
				System.out.println("******Create Account*****");
				// validating name
				String accHolderName = null;
				boolean isName = false;
				do {
					System.out.println("Enter the AccHolderName");
					accHolderName = scanner.next();
					isName = service.validateName(accHolderName);
					if (!isName) {
						System.out.println("Please enter valid account holder name with required format");
					}
				} while (!isName);
				// validating mobileno
				long mobileNo;
				boolean isMobNo;
				do {
					System.out.println("Enter the Mobileno");
					mobileNo = scanner.nextLong();
					isMobNo = service.validateMobileNo(mobileNo);
					if (!isMobNo) {
						System.out.println("please enter valid mobileno");
					}
				} while (!isMobNo);
				System.out.println("Enter the Branch");
				String branch = scanner.next();
				// validating accountType
				String accountType;
				boolean isAccType = false;
				do {
					System.out.println("Enter the Account Type ");
					accountType = scanner.next();
					isAccType = service.validateaccType(accountType);
					if (!isAccType) {
						System.out.println("please enter the valid accounttype");
					}
				} while (!isAccType);
				System.out.println("Enter the Balance:");
				int balance = scanner.nextInt();
				// long accountNo = mobileNo - 1000000;
				Bank bank = new Bank();
				bank.setAccHolderName(accHolderName);
				bank.setBranch(branch);
				bank.setmobileNo(mobileNo);
				bank.setAccType(accountType);
				bank.setBalance(balance);
				// bank.setAccountno(accountNo);
				
				long accNo = service.insertCreateAccount(bank);
				System.out.println("****Account Created****");
				System.out.println("Accountno:" + accNo);
				break;
			case 2:
				// show account balance
				try {
					System.out.println("******Show Balance*******");
					System.out.println("Enter the Accountno");
					long accountNo1 = scanner.nextLong();
					long bk = service.retriveShowBalance(accountNo1);
					System.out.println("Your Availablebalance is" + bk);
				} catch (AccountNumberNotFoundException e) {
					e.printStackTrace();
					System.out.println("Cannot display the balance because of incorrect Accountno");
				}

				break;
			case 3:
				// Deposit
				try {
					System.out.println("*******Deposite*******");
					System.out.println("Enter the Accountno");
					long accountNo2 = scanner.nextLong();
					System.out.println("Enter the Amount to Deposite");
					long depositeAmount = scanner.nextInt();
					long bkk = service.deposit(accountNo2, depositeAmount);
					System.out.println("The Updated Amount" + bkk);
				} catch (AccountNumberNotFoundException e) {
					e.printStackTrace();
					System.out.println("Cannot deposite because of incorrect Accountno");
				}
				break;
			case 4:
				// withdraw
				try {
					System.out.println("******Withdraw*******");
					System.out.println("Enter the Accountno");
					long accountNo3 = scanner.nextLong();
					System.out.println("Enter the Amount to withdraw");
					long withdrawAmount = scanner.nextLong();
					long wa = service.withdraw(accountNo3, withdrawAmount);
					System.out.println("The Updated Amount" + wa);
				} catch (AccountNumberNotFoundException e) {
					e.printStackTrace();
					System.out.println("Cannot withdraw please enter the valid Accountno");
				}
				break;
			case 5:
				// fund transaction
				try {
					System.out.println("******Fund Transaction*******");
					System.out.println("Enter the Sender Accountno");
					long accountNo4 = scanner.nextLong();
					System.out.println("Enter the Receiver Accountno");
					long accountNo5 = scanner.nextLong();
					System.out.println("Enter the Amount to Transfer");
					long transferAmount = scanner.nextLong();
					long ft = service.fundTransfer(accountNo4, accountNo5, transferAmount);
					System.out.println("Available Balance" + ft);
				} catch (AccountNumberNotFoundException e) {
					e.printStackTrace();
					System.out.println("Invalid accountno");
				} catch (AmountExceedException e) {
					// e.printStackTrace();
					System.out.println("amount is insufficient enter the valid amount");
				}

				break;
			case 6:
				// Printing transaction details

				System.out.println("*****Print Transaction******");
				List<Transaction>trans=service.printTransaction();
				
				for(Transaction e1:trans){
					System.out.println("Trans ID:"+e1.gettId()+"  "+"FromAccount:"+e1.getFromAccount()+"  "+"ToAccount:"+e1.getToAccount()+"  "+"OldBal:"+e1.getOldBalance()+"  "+"NewBal:"+e1.getNewBAlance()+"  "+"Transtype:"+e1.getTranscationType());
				
				}
				System.out.println("Thank you");

			break;
		}
	}
}
}

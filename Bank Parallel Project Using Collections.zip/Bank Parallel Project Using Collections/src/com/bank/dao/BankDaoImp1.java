package com.bank.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bank.bean.BankDetails;
import com.bank.bean.BankTransactions;
import com.bank.execptions.AccountNumberNotFoundException;

public class BankDaoImp1 implements BankDao {
	
	
	Map<Long, BankDetails> bankdetail = new HashMap<Long, BankDetails>();  //Storing details in Map

	Map<BankTransactions, Long> transInfo = new HashMap<BankTransactions, Long>(); //Storing details in another Map for printing purpose 

	//Logic to store the details in map
	@Override
	public long createAccount(BankDetails bankdetails) {
		bankdetail.put(bankdetails.getAccNum(), bankdetails);
		return bankdetails.getAccNum();
	}

	//Logic to display the details
	@Override
	public BankDetails showDetails(long accNum) {
		// System.out.println(accNum);
		BankDetails bande = bankdetail.get(accNum);
		if (bande == null) {
			throw new AccountNumberNotFoundException("Enter Valid acc number");
		}
		return bande;
	}
	 
	//Logic for depositing amount
	@Override
	public long depositDetails(long accNum, long depAcc) {
		// BankDetails bankdet=bankdetail.get(accNum);
		BankDetails bal = bankdetail.get(accNum);
		long prevBal = bal.getAccBal();
		long newBal = prevBal + depAcc;
		bal.setAccBal(newBal);
		
		BankTransactions bankTrans = new BankTransactions();
		bankTrans.setTransId(1234);
		bankTrans.setTransNewBal(newBal);
		bankTrans.setTransType("Deposit");
		transInfo.put(bankTrans, accNum);
		bankTrans.setAccNum(accNum);
		bankTrans.setCustBranch(bal.getCustBranch());
		bankTrans.setCustMobNum(bal.getCustMobNum());
		bankTrans.setCustName(bal.getCustName());
		bankTrans.setTransOldBal(prevBal);
		bankTrans.setFromAcc(accNum);
		//System.out.println(transInfo.size());

		return newBal;
	}

	//Logic for withdrawing amount
	@Override
	public long withdrawDetails(long accNum, long withDraw) {
		BankDetails bal = bankdetail.get(accNum);
		long prevBal = bal.getAccBal();
		if(prevBal<withDraw)
		{
			System.out.println("provide proper withdrawn amount");
		}
		else
		{
			long newBal = prevBal - withDraw;
			bal.setAccBal(newBal);
		}
		long newBal = prevBal - withDraw;
		bal.setAccBal(newBal);
		BankTransactions bankTrans1 = new BankTransactions();
		long transIdGen = bal.getAccNum();
		long transIdGen1 = transIdGen - 100;
		bankTrans1.setTransId(transIdGen1);
		bankTrans1.setTransNewBal(newBal);
		bankTrans1.setTransType("WithDraw");
		bankTrans1.setAccNum(accNum);
		bankTrans1.setCustBranch(bal.getCustBranch());
		bankTrans1.setCustMobNum(bal.getCustMobNum());
		bankTrans1.setCustName(bal.getCustName());
		bankTrans1.setTransOldBal(prevBal);
		bankTrans1.setFromAcc(accNum);

		transInfo.put(bankTrans1, accNum);
		//System.out.println(transInfo.size());

		return newBal;
	}
	
	//Logic for fund transferring amount
	@Override
	public long fundTransfer(long accNum4, long accNum5, long fundTrans) {
		BankDetails bal = bankdetail.get(accNum4);
		BankDetails balTrans = bankdetail.get(accNum5);
		long sendBal = bal.getAccBal() - fundTrans;
		long recieveBal = balTrans.getAccBal() + fundTrans;
		bal.setAccBal(sendBal);
		balTrans.setAccBal(recieveBal);
		if (sendBal < fundTrans) {
			System.out.println("Insufficient Balance!!");
		} else {
			System.out.println("Transfered Successful!!");
		}
		BankTransactions bankTrans2 = new BankTransactions();
		bankTrans2.setTransId(1234);
		bankTrans2.setFromAcc(sendBal);
		bankTrans2.setToAcc(recieveBal);
		bankTrans2.setTransNewBal(sendBal);
		bankTrans2.setTransType("Fund transfer");
		bankTrans2.setAccNum(accNum4);
		bankTrans2.setCustBranch(bal.getCustBranch());
		bankTrans2.setCustMobNum(bal.getCustMobNum());
		bankTrans2.setCustName(bal.getCustName());
		bankTrans2.setTransOldBal(sendBal);
		bankTrans2.setFromAcc(accNum4);
		bankTrans2.setToAcc(accNum5);

		transInfo.put(bankTrans2, accNum4);

		return sendBal;
	}
	
	@Override
	public List<BankTransactions> printTransactions() {
		List<BankTransactions> list = new ArrayList<BankTransactions>(transInfo.keySet());
		return list;
	}

}

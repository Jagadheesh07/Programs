package com.bank.bean;

public class BankTransactions {
	private long transId;
	private String custName;
	private long custMobNum;
	private String transType;
	private long transOldBal;
	private String custBranch;
	private long accNum;
	private long fromAcc;
	private long toAcc;
	private long transNewBal;
//setter and getters
	public long getTransId() {
		return transId;
	}

	public void setTransId(long transId) {
		this.transId = transId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public long getCustMobNum() {
		return custMobNum;
	}

	public void setCustMobNum(long custMobNum) {
		this.custMobNum = custMobNum;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public long getTransOldBal() {
		return transOldBal;
	}

	public void setTransOldBal(long transOldBal) {
		this.transOldBal = transOldBal;
	}

	public String getCustBranch() {
		return custBranch;
	}

	public void setCustBranch(String custBranch) {
		this.custBranch = custBranch;
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public long getFromAcc() {
		return fromAcc;
	}

	public void setFromAcc(long fromAcc) {
		this.fromAcc = fromAcc;
	}

	public long getToAcc() {
		return toAcc;
	}

	public void setToAcc(long toAcc) {
		this.toAcc = toAcc;
	}

	public long getTransNewBal() {
		return transNewBal;
	}

	public void setTransNewBal(long transNewBal) {
		this.transNewBal = transNewBal;
	}

	@Override
	public String toString() {
		return "BankTransactions [transId=" + transId + ", custName=" + custName + ", custMobNum=" + custMobNum
				+ ", transType=" + transType + ", transOldBal=" + transOldBal + ", custBranch=" + custBranch
				+ ", accNum=" + accNum + ", fromAcc=" + fromAcc + ", toAcc=" + toAcc + ", transNewBal=" + transNewBal
				+ "]";
	}

}

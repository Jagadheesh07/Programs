package com.bank.service;


//import java.util.Iterator;
import java.util.List;

import com.bank.bean.BankDetails;
import com.bank.bean.BankTransactions;

public interface BankService 
{
	long createAccount(BankDetails bankdetails);
	BankDetails showDetails(long accNum);
	long depositDetails(long accNum,long depAcc);
	long withdrawDetails(long accNum,long withDraw);
	long fundTransfer(long accNum4,long accNum5,long fundTrans);
	List<BankTransactions> printTransactions();
	boolean validateName(String custName);
	boolean validateMobNum(long custMobNum);
	boolean validateAccType(String accType);
}

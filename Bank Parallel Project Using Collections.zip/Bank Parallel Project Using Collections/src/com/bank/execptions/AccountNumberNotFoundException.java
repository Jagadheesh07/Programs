package com.bank.execptions;

@SuppressWarnings("serial")
public class AccountNumberNotFoundException extends RuntimeException
{
	 public AccountNumberNotFoundException(final String m)
	 {
		 super(m);
	 }
}

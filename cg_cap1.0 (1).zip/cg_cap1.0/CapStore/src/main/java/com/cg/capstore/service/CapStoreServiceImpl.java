package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.CapStoreDao;
import com.cg.capstore.entity.CartQuantityProduct;
import com.cg.capstore.entity.Category;
import com.cg.capstore.entity.Customer;
import com.cg.capstore.entity.Merchant;
import com.cg.capstore.entity.Order;
import com.cg.capstore.entity.OrderQuantityProduct;
import com.cg.capstore.entity.Product;
import com.cg.capstore.entity.Transaction;
import com.cg.capstore.entity.ViewProduct;
import com.cg.capstore.exception.CapStoreException;
import com.cg.capstore.exception.MerchantException;
import com.cg.capstore.exception.ProductException;

@Service
public class CapStoreServiceImpl implements CapStoreService {

	@Autowired
	CapStoreDao capStoreDao;

	@Override
	public String placingOrder(Order order,OrderQuantityProduct orderQuantityProduct) throws CapStoreException {
		return capStoreDao.placingOrder(order,orderQuantityProduct);
	}

	@Override
	public Customer getCustomeradmin(int cust_id) throws CapStoreException {
		return capStoreDao.getCustomer(cust_id);
	}

	@Override
	public List<Customer> getAllCustomer() throws CapStoreException {
		return capStoreDao.getAllCustomer();
	}

	@Override
	public List<Merchant> getAllMerchant() throws CapStoreException {
		
		return capStoreDao.getAllMerchant();
	}

	@Override
	public List<Product> getAllProducts() throws CapStoreException {
		
		return capStoreDao.getAllProducts();
	}

	@Override
	public List<Order> getAllOrders() throws CapStoreException {
		
		return capStoreDao.getAllOrders();
	}

	@Override
	public boolean manageMerchant(int merchantId, boolean flag) throws CapStoreException {
		
		return capStoreDao.manageMerchant(merchantId, flag);
	}

	@Override
	public boolean updateProductStatusByAdmin(int id, boolean flag) throws CapStoreException {
		
		return capStoreDao.updateProductStatusByAdmin(id, flag);
	}

	@Override
	public boolean removeMerchant(int merchantId) throws CapStoreException {
		
		return capStoreDao.removeMerchant(merchantId);
		
	}

	@Override
	public List<Integer> getDispatchReport(int productId) throws CapStoreException {
		
		return capStoreDao.getDispatchReport(productId);
	}

	@Override
	public List<Integer> getDispatchReportCategoryall() throws CapStoreException {
		
		return capStoreDao.getDispatchReportCategoryall();
	}

	@Override
	public List<Integer> getDispatchReportsubcatgory(String category) throws CapStoreException {
		
		return capStoreDao.getDispatchReportsubcatgory(category);
	}

	@Override
	public List<Integer> getDispatchReportCategory(int productId) throws CapStoreException {
		
		return capStoreDao.getDispatchReportCategory(productId);
	}

	@Override
	public List<Integer> getDispatchReportMerchant(int merchantId) throws CapStoreException {
		
		return capStoreDao.getDispatchReportMerchant(merchantId);
	}

	@Override
	public List<Category> getAllcategory() throws CapStoreException {
		
		return capStoreDao.getAllcategory();
	}

	@Override
	public boolean customerSignUp(Customer customer, String password) throws CapStoreException {
		
		return capStoreDao.customerSignUp(customer, password);
	}

	@Override
	public boolean merchantSignUp(Merchant merchant, String password) throws CapStoreException {
		
		return capStoreDao.merchantSignUp(merchant, password);
	}
	
	//****************************************************************************************************************************************
	
	
	@Override
	public int addProduct(Product product) {
		
		return capStoreDao.addProduct(product);
	}

	@Override
	public String updateInventory(int ProductId, int Quantity, double ProductPrice) throws ProductException {
		
		return capStoreDao.updateInventory(ProductId, Quantity, ProductPrice);
	}

	@Override
	public String deleteProduct(int ProductId) throws ProductException {
		
		return capStoreDao.deleteProduct(ProductId);
	}

	@Override
	public Product searchByProductId(int MerchantId, int productId) throws ProductException {
		
		return capStoreDao.searchByProductId(MerchantId, productId);
	}

	@Override
	public List<Product> searchByOrderId(int merchantId, int orderId) throws ProductException, MerchantException {
		
		return capStoreDao.searchByOrderId(merchantId, orderId);
	}

	@Override
	public boolean loginMerchant(int merchantId, String password) throws MerchantException {
		 
		return capStoreDao.loginMerchant(merchantId, password);
	}

	@Override
	public List<Product> listAllProducts(int merchantId) throws MerchantException {
		
		return capStoreDao.listAllProducts(merchantId);
	}

	
	@Override
	public int uploadImagemerchant(int productid,String imagelink) {
		
		return capStoreDao.uploadImage(productid,imagelink);
	}

	@Override
	public int addCategory(Category category) {
		
		return capStoreDao.addCategory(category);
	}

	@Override
	public List<OrderQuantityProduct> listOrders(int merchantId) {
		
		return capStoreDao.listOrders(merchantId);
	}

	@Override
	public boolean updateProductStatusByMerchant(int id, boolean flag) throws CapStoreException {
		
		return capStoreDao.updateProductStatusByMerchant(id, flag);
	}
	
//customer team 1##########################################################################
	@Override
	public Customer getCustomer(int cust_id) throws CapStoreException {
		return capStoreDao.getCustomer(cust_id);
	}

	@Override
	public String transactionDetails(int OrderId ,Transaction transaction) throws CapStoreException{
		return capStoreDao.transactionDetails(OrderId,transaction);
	}

	@Override
	public List<OrderQuantityProduct> getShippingDetails(int order_id) throws CapStoreException {
		return capStoreDao.getShippingDetails(order_id);
	}

	@Override
	public List<Product> searchProduct(String prod_name) throws CapStoreException {
		return capStoreDao.searchProduct(prod_name);
	}

	@Override
	public Product getProduct(int productId) throws CapStoreException {
		return capStoreDao.getProduct(productId);
	}

	@Override
	public String updateAddress(int customerId, String address) throws CapStoreException {
		return capStoreDao.updateAddress(customerId, address);
	}

	@Override
	public List<Order> getYourOrders(int customerId) throws CapStoreException {
		return capStoreDao.getYourOrders(customerId);
	}

	
//customer team2 work##########################################################################
	@Override
	public boolean loginCustomer(int customerId, String password) throws CapStoreException {
		return capStoreDao.loginCustomer(customerId, password);
	}

	@Override
	public List<CartQuantityProduct> searchProductFromCart(String prod_name, int cust_id) throws CapStoreException {
		return capStoreDao.searchProductFromCart(prod_name, cust_id);
		}

	@Override
	public List<ViewProduct> listProductByMostViewed() throws CapStoreException {
		return capStoreDao.listProductByMostViewed();
	}

	@Override
	public List<ViewProduct> listProductBasedOnBestSeller() throws CapStoreException {
		return capStoreDao.listProductBasedOnBestSeller();
	}

	@Override
	public List<Product> listProductPriceInAscOrder() throws CapStoreException {
		return capStoreDao.listProductPriceInAscOrder();
	}

	@Override
	public List<Product> listProductPriceInDescOrder() throws CapStoreException {
		return capStoreDao.listProductPriceInDescOrder();
	}

	@Override
	public List<Product> getProductByPriceRange(double low, double high) throws CapStoreException {
		return capStoreDao.getProductByPriceRange(low, high);
	}

	@Override
	public List<Product> listOfSimilarProducts(String prod_name) throws CapStoreException {
		return capStoreDao.listOfSimilarProducts(prod_name);
	}

	@Override
	public String addProductToCart(int prod_id, int cust_id, int quantity) throws CapStoreException {
		return capStoreDao.addProductToCart(prod_id, cust_id, quantity);
	}

	@Override
	public List<CartQuantityProduct> listAllCartProduct(int Cust_id) throws CapStoreException {
		return capStoreDao.listAllCartProduct(Cust_id);
	}

	@Override
	public String removeProductFromCart(int prod_id, int cust_id) throws CapStoreException {
		return capStoreDao.removeProductFromCart(prod_id, cust_id);
	}

	@Override
	public String updateProductInCart(int quantity, int prod_id, int cust_id) throws CapStoreException {
		return capStoreDao.updateProductInCart(quantity, prod_id, cust_id);
	}

	@Override
	public int placingOrder(int customerId) throws CapStoreException {
		
		return capStoreDao.placingOrder( customerId);
	}

	@Override
	public int uploadImage(int productid, String imagelink) {
		return capStoreDao.uploadImage(productid, imagelink);
	}

	@Override
	public String updateProfileDetails(Customer customer) throws CapStoreException {
		return capStoreDao.updateProfileDetails(customer);
	}




}

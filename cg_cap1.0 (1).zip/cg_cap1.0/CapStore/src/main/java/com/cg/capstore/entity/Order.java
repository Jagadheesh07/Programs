package com.cg.capstore.entity;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="j_order")
public class Order {
	
	
	@Id
	@GeneratedValue
	@Column(name="order_id")
	private int orderId;
	
	@Column(name="order_date")
	private Date orderDate;
	
	@Column (name="order_time")
	private String orderTime;
	
	@Column(name="order_address",length=100)
	private String orderShippingAddress;
	
	@Column(name="order_status")
	private String orderStatus;
	
	
	@OneToOne
	@JoinColumn(name="cust_id")
	private Customer customer;
	
	
	@OneToMany(mappedBy="order",targetEntity=OrderQuantityProduct.class)
	private List<OrderQuantityProduct> orderQuantityProducts=new ArrayList<OrderQuantityProduct>();

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}

	public String getOrderShippingAddress() {
		return orderShippingAddress;
	}

	public void setOrderShippingAddress(String orderShippingAddress) {
		this.orderShippingAddress = orderShippingAddress;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public List<OrderQuantityProduct> getOrderQuantityProducts() {
		return orderQuantityProducts;
	}

	public void setOrderQuantityProducts(List<OrderQuantityProduct> orderQuantityProducts) {
		this.orderQuantityProducts = orderQuantityProducts;
	}
	

	
}

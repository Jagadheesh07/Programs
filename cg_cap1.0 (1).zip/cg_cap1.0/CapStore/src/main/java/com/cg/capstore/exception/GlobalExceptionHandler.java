package com.cg.capstore.exception;
import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(CapStoreException.class)
	public @ResponseBody ErrorInfo handler(CapStoreException exp,HttpServletRequest request)
	{
		LocalDateTime timestamp=LocalDateTime.now();
		String message=exp.getMessage();
		String uri=request.getRequestURI();
		ErrorInfo error=new ErrorInfo(timestamp,message,uri);
		return error;
	}

	@ExceptionHandler(ProductException.class)
	public @ResponseBody ErrorInfo productExceptionHandler(ProductException exp,HttpServletRequest request)
	{
		LocalDateTime timestamp=LocalDateTime.now();
		String message=exp.getMessage();
		String uri=request.getRequestURI();
		ErrorInfo error=new ErrorInfo(timestamp,message,uri);
		return error;
	}
	
	@ExceptionHandler(MerchantException.class)
	public @ResponseBody ErrorInfo merchantExceptionHandler(MerchantException exp,HttpServletRequest request)
	{
		LocalDateTime timestamp=LocalDateTime.now();
		String message=exp.getMessage();
		String uri=request.getRequestURI();
		ErrorInfo error=new ErrorInfo(timestamp,message,uri);
		return error;
	}

}

package com.cg.capstore.entity;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="l_transactions_tbl")
public class Transaction {
	
	@Id
	@GeneratedValue
	@Column(name="tran_id")
	private int transactionId;
	
	@Column(name="tran_type",length=20)
	private String transactionType;
	
	@Column(name="tran_date")
	private Date transactionDate;
	
	@Column(name="tran_time")
	private String transactionTime;
	
	@Column(name="tran_amount")
	private double transactionAmount;
	
	@Column(name="tran_status",length=20)
	private String transactionStatus;
	

	@OneToOne
	@JoinColumn(name="order_id")
	private Order order;

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(String transactionTime) {
		this.transactionTime = transactionTime;
	}

	public double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}
	
	
	

}

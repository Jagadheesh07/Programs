package com.cg.capstore.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="c_category_tbl")
public class Category {
	
	@Id
	@GeneratedValue
	@Column(name="category_id")
	private int categoryId;
	
	
	@Column(name="category_name")
	private String categoryName;
	
	@Column(name="category_subcategory")
	private String subCategory;
	
	@JsonIgnore
	@OneToMany(mappedBy = "category",targetEntity=Product.class)
	List<Product> listOfProduct =new ArrayList<Product>();
	

	public String getSubCategory() {
		return subCategory;
	}


	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}


	public int getCategoryId() {
		return categoryId;
	}


	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}


	public String getCategoryName() {
		return categoryName;
	}


	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	
	

}

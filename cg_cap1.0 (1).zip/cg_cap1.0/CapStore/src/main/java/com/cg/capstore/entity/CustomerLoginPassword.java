package com.cg.capstore.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="f_customer_login_pass_tbl")
public class CustomerLoginPassword 
{
	@Id
	@GeneratedValue
	@Column(name="id")
	private int id;
	


	@OneToOne
	@JoinColumn(name="cust_id")
	private Customer customer;
	
	
	@Column(name="password",length=100)
	private String password;


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	

}

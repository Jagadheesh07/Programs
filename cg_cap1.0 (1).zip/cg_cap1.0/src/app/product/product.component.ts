import { Component, OnInit } from '@angular/core';
import { CapstoreService } from '../capstore.service';
import { Product } from '../product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  products:Product[];
  constructor(private service:CapstoreService) { }

  ngOnInit() {
    this.service.getAllProducts().subscribe(data=>this.products=data);
  }

}

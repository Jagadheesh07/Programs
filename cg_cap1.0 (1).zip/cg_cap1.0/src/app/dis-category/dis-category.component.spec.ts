import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisCategoryComponent } from './dis-category.component';

describe('DisCategoryComponent', () => {
  let component: DisCategoryComponent;
  let fixture: ComponentFixture<DisCategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisCategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

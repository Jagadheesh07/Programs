import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomersingnupComponent } from './customersingnup.component';

describe('CustomersingnupComponent', () => {
  let component: CustomersingnupComponent;
  let fixture: ComponentFixture<CustomersingnupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomersingnupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomersingnupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

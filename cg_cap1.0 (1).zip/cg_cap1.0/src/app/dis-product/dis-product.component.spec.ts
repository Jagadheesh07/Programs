import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisProductComponent } from './dis-product.component';

describe('DisProductComponent', () => {
  let component: DisProductComponent;
  let fixture: ComponentFixture<DisProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

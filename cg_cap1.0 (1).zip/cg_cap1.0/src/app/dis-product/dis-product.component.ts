import { Component, OnInit } from '@angular/core';
import { Chart } from 'chart.js';
import { Product } from '../product';
import { CapstoreService } from '../capstore.service';

import Swal from 'sweetalert2';


@Component({
  selector: 'app-dis-product',
  templateUrl: './dis-product.component.html',
  styleUrls: ['./dis-product.component.css']
})
export class DisProductComponent implements OnInit {
    errorMessage:string;
  LineChart=[];
  BarChart=[];
  products:Product[];
  productCount:number [];
  constructor(private service:CapstoreService) { }

  


  

  ngOnInit() {
    this.service.getAllProducts().subscribe(data=>this.products=data);
   
      
  
  }
 
     
   
    
    onsumbit(pro:Product){
        this.BarChart= new Chart('linechart2', {
            type: 'bar',
            data: {
                labels: ['Sunday','Monday', 'Tuesday', 'Wednesday', 'Thrusday', 'Friday', 'Saturday'],
                datasets: [{
                    label: 'Number of Product Sold',
                    data: this.productCount,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(155, 139, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(155, 139, 64, 0.2)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    this.service.getDispatchReport(pro.productId).subscribe(data=>{
        if(data["errorMessage"]!=undefined){
            this.errorMessage=data["errorMessage"]

        }
        else{
            data=this.productCount=data;
        }
    })
    
 



    
  }

}



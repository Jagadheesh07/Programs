import { Customer } from 'src/app/customer';
import { Product } from 'src/app/productlist/product';


export class CartQuantityProduct
{
    id:number
    customer:Customer
    product:Product
    quantity:number
}
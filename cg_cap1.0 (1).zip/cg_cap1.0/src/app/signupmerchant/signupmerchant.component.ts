import { Component, OnInit } from '@angular/core';
import { Merchant } from '../merchant';
import { CapstoreService } from '../capstore.service';

@Component({
  selector: 'app-signupmerchant',
  templateUrl: './signupmerchant.component.html',
  styleUrls: ['./signupmerchant.component.css']
})
export class SignupmerchantComponent implements OnInit {

  merchant:Merchant=new Merchant();
  errorMessage:string;
  status=false;
  password:string;

  constructor(private service : CapstoreService) { }

  ngOnInit() {
  }

  onSubmit(){
    this.service.merchantSignUp(this.merchant,this.password).subscribe(data=>{
      if(data["errorMessage"]!=undefined){
        this.errorMessage=data["errorMessage"];
        this.status=false
      }
      else{
        this.status=data;
      }

    });
  }
}

import { Component, OnInit } from '@angular/core';
import { CapStoreService } from '../cap-store.service';

@Component({
  selector: 'app-returngoods',
  templateUrl: './returngoods.component.html',
  styleUrls: ['./returngoods.component.css']
})
export class ReturngoodsComponent implements OnInit {

  constructor(private service: CapStoreService) { }

  ngOnInit() {
  }
  orderid: number
  productid: number
  quantity: number
  message: boolean


  submit() {
    this.service.returngoods(this.productid, this.orderid, this.quantity).subscribe(data => this.message = data)

  }


}

import { TestBed } from '@angular/core/testing';

import { AuthguardmerchantService } from './authguardmerchant.service';

describe('AuthguardmerchantService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AuthguardmerchantService = TestBed.get(AuthguardmerchantService);
    expect(service).toBeTruthy();
  });
});

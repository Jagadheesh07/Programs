import { TestBed } from '@angular/core/testing';

import { AuthgaurdCustomerService } from './authgaurd-customer.service';

describe('AuthgaurdCustomerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AuthgaurdCustomerService = TestBed.get(AuthgaurdCustomerService);
    expect(service).toBeTruthy();
  });
});

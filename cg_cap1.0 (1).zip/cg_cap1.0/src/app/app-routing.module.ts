import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { QuestionanswerComponent } from './questionanswer/questionanswer.component';
import { ErrorpageComponent } from './errorpage/errorpage.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { SortbyComponent } from './sortby/sortby.component';
import { ProductpageComponent } from './productpage/productpage.component';
import { componentFactoryName } from '@angular/compiler';
import { ProfileComponent } from './profile/profile.component';
import { YourorderComponent } from './yourorder/yourorder.component';
import { ReturngoodsComponent } from './returngoods/returngoods.component';
import { LoginCustomerComponent } from './login-customer/login-customer.component';
import { ListallproductComponent } from './cart/listallproduct.component';
import { AuthgaurdCustomerService } from './authgaurd-customer.service';
import { TransactionComponent } from './transaction/transaction.component';
import { ShippingComponent } from './shipping/shipping.component';

import { CustomerComponent } from './customer/customer.component';
import { MerchantComponent } from './merchant/merchant.component';
import { ProductComponent } from './product/product.component';
import { OrderComponent } from './order/order.component';
import { AnalysisComponent } from './analysis/analysis.component';
import { DisProductComponent } from './dis-product/dis-product.component';
import { DisCategoryComponent } from './dis-category/dis-category.component';
import { DisMerchantComponent } from './dis-merchant/dis-merchant.component';

//******************************************************8 */

import { LoginmerchantComponent } from './loginmerchant/loginmerchant.component';
import { AddproductComponent } from './addproduct/addproduct.component';

import { AuthguardmerchantService } from './authguardmerchant.service';
import { SearchbyorderComponent } from './searchbyorder/searchbyorder.component';
import { SearchbyproductComponent } from './searchbyproduct/searchbyproduct.component';

import { SignupmerchantComponent } from './signupmerchant/signupmerchant.component';
import { MerchantpageComponent } from './merchantpage/merchantpage.component';

import { ListproductsComponent } from './listproducts/listproducts.component';
import { AddcategoryComponent } from './addcategory/addcategory.component';
import { AdminComponent } from './admin/admin.component';
import { ListordersComponent } from './listorders/listorders.component';
import { LogoutmerchantComponent } from './logoutmerchant/logoutmerchant.component';
import { MerchantsignupComponent } from './merchantsignup/merchantsignup.component';
import { CustomersingnupComponent } from './customersingnup/customersingnup.component';

const routes: Routes = [

  { path: 'home', component: HomeComponent },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',

  },
{path:'login',
component:LoginCustomerComponent},
{path:'cart',
component:ListallproductComponent,
canActivate:[AuthgaurdCustomerService]},
{path:'transaction/:orderid/:totalamount',
component:TransactionComponent},
  { path: 'qa', component: QuestionanswerComponent },
  { path: 'error', component: ErrorpageComponent },
  { path: 'productlist/:searchname', component: ProductlistComponent },
  { path: 'productpage/:prod_id', component: ProductpageComponent },
{path:'invoice/:orderid',
component:ShippingComponent},
  {
    path: 'myprofile', component: ProfileComponent
  },
  {
    path: 'yourOrder', component: YourorderComponent
  },
  { path: 'returngood', component: ReturngoodsComponent },
  {path:'admin',
  component:AdminComponent,children:[
  { 
    path:'customer',
    component:CustomerComponent
  },
  {
    path:'merchant',
    component:MerchantComponent
  },
  {
    path:'product',
    component:ProductComponent
  },
  {
    path:'order',
    component:OrderComponent
  },
  {
    path:'analysis',
    component:AnalysisComponent

  ,children:
  [{
    path:'dis_product',
    component:DisProductComponent
  },
  {
    path:'dis_category',
    component:DisCategoryComponent
  },
  {
    path:'dis_merchant',
    component:DisMerchantComponent
  }]}]},
  //******************************************************************* */
  {
    path:"loginMerchant",
    component:LoginmerchantComponent
    
  },
  {
    path:"merchantPage",
    component:MerchantpageComponent,
    canActivate:[AuthguardmerchantService]
  },
  
  {
    path:"signupMerchant",
    component:SignupmerchantComponent
  },
  {
    path:"addProduct",
    component:AddproductComponent
  },
  {
    path:"listProducts",
    component:ListproductsComponent
  },
  
  {
    path:"searchByOrder",
    component:SearchbyorderComponent
  },
  {
    path:"addcategory",
    component:AddcategoryComponent
  },
  {
    path:"searchByProduct",
    component:SearchbyproductComponent
  },
  {
    path:"listOrders",
    component:ListordersComponent
  },
  {
    path:"logoutMerchant",
    component:LogoutmerchantComponent
  },
  //*********************************************************** */
  {path:'merchantsignup',
  
  component:MerchantsignupComponent
},
  {
    path:'customersignup',
    component:CustomersingnupComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

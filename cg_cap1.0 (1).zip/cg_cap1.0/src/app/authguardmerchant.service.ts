import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { MerchantService } from './merchant.service';

@Injectable({
  providedIn: 'root'
})
export class AuthguardmerchantService implements CanActivate
{
  
  constructor() { }

  canActivate() : boolean{
    if(sessionStorage.getItem("status").localeCompare("true")==0)
    {
      
       return true;
    }
    else{
      return false;
    }
    
  }
}

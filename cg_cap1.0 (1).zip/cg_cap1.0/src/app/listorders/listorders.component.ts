import { Component, OnInit } from '@angular/core';
import { Order } from '../order';
import { MerchantService } from '../merchant.service';
import { Router } from '@angular/router';
import { OrderQuantityProduct } from '../orderquantityproduct';

@Component({
  selector: 'app-listorders',
  templateUrl: './listorders.component.html',
  styleUrls: ['./listorders.component.css']
})
export class ListordersComponent implements OnInit {


  errorMessage:string
  status=false;

  orderId : number;
  orderIdList : number[];

  orderQuantityList : OrderQuantityProduct[];

  constructor(private service : MerchantService, private router: Router) { }

  ngOnInit() {
     this.service.listOrders().subscribe(data => this.orderQuantityList =data);
   
  }


  approve(orderquantity :OrderQuantityProduct) {
    
        
       this.service.updateProductStatusByMerchant(orderquantity.id,true).subscribe(data=>{
         if(data["errorMessage"]!=undefined){
           this.errorMessage=data["errorMessage"]
         }
         else
         {
           this.status=data
         }
       });
       this.router.navigateByUrl('/merchantPage', { skipLocationChange: true }).then(() => {
        this.router.navigate(['/listOrders']);
      });
        
      }
    
      reject(orderquantity:OrderQuantityProduct) {
        console.log(orderquantity.id)
    
        this.service.updateProductStatusByMerchant(orderquantity.id,false).subscribe(data=>{
          if(data["errorMessage"]!=undefined){
            this.errorMessage=data["errorMessage"]
          }
          else
          {
            this.status=data
          }
        });
        this.router.navigateByUrl('/merchantPage', { skipLocationChange: true }).then(() => {
          this.router.navigate(['/listOrders']);
        });
      }
}

import { Product } from './productlist/product';

export class Image
{
    id:number
    product:Product
    imageLink:string
}
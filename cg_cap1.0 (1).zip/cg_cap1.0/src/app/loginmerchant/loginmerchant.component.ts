import { Component, OnInit } from '@angular/core';
import { MerchantService } from '../merchant.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-loginmerchant',
  templateUrl: './loginmerchant.component.html',
  styleUrls: ['./loginmerchant.component.css']
})
export class LoginmerchantComponent implements OnInit {

   merchantId: number;
   password : string;

   status : boolean=false;
   errmessage : string;


  constructor(private service : MerchantService,private router : Router) { }

  ngOnInit() {
  }

  login()
  {
    this.status=true;
  }

  loginMerchant()
  {
    this.service.loginMerchant(this.merchantId,this.password).subscribe(data =>
    
    {
      if(data["errorMessage"]!=undefined)
    {
      this.errmessage=data["errorMessage"];
      alert(this.errmessage);
      this.password="";
    }
    else{

      sessionStorage.setItem("status","true");  
      sessionStorage.setItem("merchantId",this.merchantId.toString());   
    
      this.router.navigate(["merchantPage"]);
    }
    }
    );
  }

}


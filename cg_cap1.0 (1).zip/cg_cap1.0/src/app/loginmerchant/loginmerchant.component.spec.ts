import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginmerchantComponent } from './loginmerchant.component';

describe('LoginmerchantComponent', () => {
  let component: LoginmerchantComponent;
  let fixture: ComponentFixture<LoginmerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginmerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginmerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

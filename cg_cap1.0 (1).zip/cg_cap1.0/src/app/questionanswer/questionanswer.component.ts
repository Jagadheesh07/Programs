import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2'
import { CapStoreService } from '../cap-store.service';
import { Order } from '../order';

@Component({
  selector: 'app-questionanswer',
  templateUrl: './questionanswer.component.html',
  styleUrls: ['./questionanswer.component.css']
})
export class QuestionanswerComponent implements OnInit {

  constructor(private service:CapStoreService) { }

  
  ngOnInit() {
  }
submit(){
  Swal.fire({
    type:'success',
    title:'Goods Returned!!',
    showConfirmButton:false,
    timer:1500
    })
    //routing parameter ....service left for returngoods
}
}

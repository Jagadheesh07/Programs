import { Product } from './productlist/product';


export class ViewProduct
{
    product: Product;
    productViewCount: number;
    productOrderCount: number;

}
import { Component, OnInit } from '@angular/core';

import Swal from 'sweetalert2'
import { CapStoreService } from 'src/app/cap-store.service';
import { Transaction } from 'src/app/transaction';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
amount:number
  orderid:number
  transaction:Transaction=new Transaction()
  constructor(private service : CapStoreService,private route:ActivatedRoute,private router:Router) { }
message:string
  ngOnInit() {
  }
  onClickPay()
  {
this.orderid=parseInt(this.route.snapshot.paramMap.get('orderid'))

this.amount=parseInt(this.route.snapshot.paramMap.get('totalamount'))
console.log(this.amount)
    this.transaction.transactionStatus="success"
    this.transaction.transactionAmount=this.amount
    this.service.transaction(this.orderid,this.transaction).subscribe(data=>this.message=data)
    alert('Transaction done successfully !!!')
    //  Swal.fire(
    
  //   'transaction completed'
  //  )
  this.router.navigate(['/invoice/'+this.orderid])

  }
  payCash()
  {
    this.transaction.transactionType="cash"
  }
  payOnline()
  {
    this.transaction.transactionType="online"
  }
}

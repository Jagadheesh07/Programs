import { Component, OnInit } from '@angular/core';

import { Order } from 'src/app/order';
import { Customer } from 'src/app/customer';
import { OrderQuantityProduct } from '../orderquantityproduct';
import { CapStoreService } from '../cap-store.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-shipping',
  templateUrl: './shipping.component.html',
  styleUrls: ['./shipping.component.css']
})
export class ShippingComponent implements OnInit {

  shippingDetails: OrderQuantityProduct[]
  Details: OrderQuantityProduct = new OrderQuantityProduct()
  orderquantity: OrderQuantityProduct

  constructor(private service: CapStoreService,private route:ActivatedRoute ) { }
  orders: Order[]
  order : Order=new Order();
  customers: Customer[]
  customer : Customer=new Customer();
  orderId:number
  ngOnInit() {
this.orderId=parseInt(this.route.snapshot.paramMap.get('orderid'))
console.log(this.orderId)
    this.service.getShippingDetails(this.orderId).subscribe(data => {
    this.shippingDetails = data
      for (let i = 0; i < this.shippingDetails.length; i++) {
        this.order=this.shippingDetails[i].order
        console.log(this.order.orderId)
      // this.customer=this.shippingDetails[i].customer
        
      }
     
    })

  }

}

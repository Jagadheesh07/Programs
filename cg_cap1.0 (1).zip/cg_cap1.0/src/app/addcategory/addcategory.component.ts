import { Component, OnInit } from '@angular/core';
import { MerchantService } from '../merchant.service';
import { Category } from '../addproduct/category';

@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.css']
})
export class AddcategoryComponent implements OnInit {

  category:Category=new Category();
  message:string;

  constructor(private service:MerchantService) { }

  ngOnInit() {
  }

  addCategory()
  {
    this.service.addCategory(this.category).subscribe(data => {
      this.message = data
        alert(data);
      });
  }
}

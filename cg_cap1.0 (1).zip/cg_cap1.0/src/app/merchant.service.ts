import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  CapstoreUrl } from './capstoreURL';
import { Observable } from 'rxjs';
import { Product } from './addproduct/product';
import { Image } from './addproduct/image';
import { Category } from './addproduct/category';
import { OrderQuantityProduct } from './orderquantityproduct';

@Injectable({
  providedIn: 'root'
})
export class MerchantService {



  constructor(private http : HttpClient) { }

  public loginMerchant(merchantId : number,password: string): Observable<any>
  {

    return this.http.get<boolean>(CapstoreUrl.URL+"/loginMerchant/"+merchantId+"/"+password);
  }

  public addproduct(product : Product) :Observable<string>
  {
    return this.http.post<string>(CapstoreUrl.URL+"/addproduct",product,{responseType:'text' as 'json'});
  }

  public listAllProducts()
  {
    return this.http.get(CapstoreUrl.URL+"/listAllProducts/"+sessionStorage.getItem("merchantId"));
  }

  public searchByOrder(orderId : number)
  {
    return this.http.get(CapstoreUrl.URL+"/searchByOrderId/"+sessionStorage.getItem("merchantId")+"/"+orderId);
  }

  public searchByProduct(productId : number)
  {
    return this.http.get(CapstoreUrl.URL+"/searchByProductId/"+sessionStorage.getItem("merchantId")+"/"+productId);
  }

  public deleteProduct(productId : number) 
  {
    return this.http.delete(CapstoreUrl.URL+"/deleteproduct/"+productId);
  }

  public updateInventory(productId : number,quantity : number,price : number)
  {
    return this.http.get(CapstoreUrl.URL+"/updateinventory/"+productId+"/"+quantity+"/"+price,{responseType:'text'});
  }

  public uploadImage(prdouctid:number,imagelink:string) : Observable<boolean>
  {
    return this.http.post<boolean>(CapstoreUrl.URL+"/uploadimage/"+prdouctid+'/'+imagelink,{responseType:'text'});
  }

  public addCategory(category : Category) :Observable<string>
  {
    return this.http.post<string>(CapstoreUrl.URL+"/addcategory",category,{responseType:'text' as 'json'});
  }

  updateProductStatusByMerchant(id:number,flag:boolean):Observable<boolean>
  {
    return this.http.get<boolean>(CapstoreUrl.URL+"/updateProductStatusByMerchant/"+id+"/"+flag);
  }

  listOrders()
  {
    return this.http.get<OrderQuantityProduct []>(CapstoreUrl.URL+"/listOrders/"+sessionStorage.getItem("merchantId"));
  }
}

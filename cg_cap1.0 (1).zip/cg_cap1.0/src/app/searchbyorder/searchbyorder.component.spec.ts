import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchbyorderComponent } from './searchbyorder.component';

describe('SearchbyorderComponent', () => {
  let component: SearchbyorderComponent;
  let fixture: ComponentFixture<SearchbyorderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchbyorderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchbyorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

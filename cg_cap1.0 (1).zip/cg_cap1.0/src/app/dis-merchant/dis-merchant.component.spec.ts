import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisMerchantComponent } from './dis-merchant.component';

describe('DisMerchantComponent', () => {
  let component: DisMerchantComponent;
  let fixture: ComponentFixture<DisMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

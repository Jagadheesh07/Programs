import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CapStoreService } from 'src/app/cap-store.service';

@Component({
  selector: 'app-login-customer',
  templateUrl: './login-customer.component.html',
  styleUrls: ['./login-customer.component.css']
})
export class LoginCustomerComponent implements OnInit {

  custId: number;
  password : string;
  status2 : boolean=false;
  status : boolean=false;
  errmessage : string;


 constructor(private service : CapStoreService,private router : Router) { }

 ngOnInit() {
 }

 login()
 {
   this.status=true;
 }
onCheck()
{
  this.status2=true;
}
 logincustomer()
 {
   this.service.loginCustomer(this.custId,this.password).subscribe(data =>
   
   {
     if(data["errorMessage"]!=undefined)
   {
     this.errmessage=data['errorMessage'];
     alert(this.errmessage);
     this.password="";
    
     sessionStorage.removeItem("status")
   }
   else{
    
     sessionStorage.setItem("status","true");  
     sessionStorage.setItem("custId",this.custId.toString());   
  //  sessionStorage.getItem("custId")
     this.router.navigate(["home"]);
     alert(data);
   }
   }
   );
 }

}

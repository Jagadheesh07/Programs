import { Component, OnInit } from '@angular/core';
import { CapstoreService } from '../capstore.service';
import { Merchant } from '../merchant';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-merchant',
  templateUrl: './merchant.component.html',
  styleUrls: ['./merchant.component.css']
})
export class MerchantComponent implements OnInit {

  authStatus = true;
  status;
  merchant: Merchant = new Merchant();
  merchants: Merchant[];
  constructor(private service: CapstoreService, private router: Router) { }

  ngOnInit() {
    this.service.getAllMerchants().subscribe(data => this.merchants = data);
   

  }
  approve(merchant) {
    this.service.manageMerchant(merchant.merchantId, true).subscribe(data => this.status = data);
    this.router.navigateByUrl('/admin/order', { skipLocationChange: true }).then(() => {
      this.router.navigate(['/admin/merchant']);
    });
  }

  reject(merchant) {
    this.service.manageMerchant(merchant.merchantId, false).subscribe(data => this.status = data);
    this.router.navigateByUrl('/admin/order', { skipLocationChange: true }).then(() => {
      this.router.navigate(['/admin/merchant']);
    });
  }
  remove(merchant)
  {  
    Swal.fire({
      title: 'Are you sure?',
      text:'Remove Merchant '+merchant.merchantName,
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.value) {
    
        this.service.removeMerchant(merchant.merchantId).subscribe(data=>this.status=data);
        this.router.navigateByUrl('/admin/order', { skipLocationChange: true }).then(() => {
          this.router.navigate(['/admin/merchant']);
        });
        Swal.fire(
          'Deleted!',
          'Merchant deleted.',
          'success'
        )
     
      }
    })
  
    
  }
    
  
}

import { Component, OnInit } from '@angular/core';

import { MerchantService } from '../merchant.service';
import { Product } from './product';
import { Category } from './category';
import { Merchant } from './merchant';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  product: Product = new Product();
  category: Category = new Category();
  merchant: Merchant = new Merchant();

  message: string;

  constructor(private service: MerchantService) { }

  ngOnInit() {

  }

  addProduct() {

    this.product.category = this.category;
    this.merchant.merchantId = parseInt(sessionStorage.getItem("merchantId"));
    this.product.merchant = this.merchant;

    this.service.addproduct(this.product).subscribe(data => {
    this.message = data
      alert(data);
    });



  }

}

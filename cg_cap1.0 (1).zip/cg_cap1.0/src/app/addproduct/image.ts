import { Product } from './product';

export class Image
{
    id:number;
    productid : number;
    imageLink:string;
}
import { Category } from './category';
import { Merchant } from './merchant';

export class Product
{
    productId : number;
    productName : string;
    productPrice : number;
    productdescription : string;
    productBrand : string;
    productQuantity : number;
    category : Category;
    merchant : Merchant;
}
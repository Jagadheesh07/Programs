import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logoutmerchant',
  templateUrl: './logoutmerchant.component.html',
  styleUrls: ['./logoutmerchant.component.css']
})
export class LogoutmerchantComponent implements OnInit {

  constructor(private router : Router) { }

  ngOnInit() {

   alert("LOGGED OUT!!!");

    sessionStorage.removeItem("status");
    sessionStorage.removeItem("merchantId");

     this.router.navigate(["/loginMerchant"]);
  }

}

import { Component, OnInit } from '@angular/core';
import { Order } from '../order';
import { CapstoreService } from '../capstore.service';
import { Router } from '@angular/router';
import { OrderQuantityProduct } from '../orderquantityproduct';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  errorMessage:string
  status=false;
  orders: Order [];
  
allorders:Order[]
  constructor(private service:CapstoreService, private router: Router) { }

  ngOnInit() {
    this.service.getAllOrders().subscribe(data=>this.orders=data);
  }
  approve(orderquantity:OrderQuantityProduct) {
console.log(orderquantity.id)
    
   this.service.updateProductStatusByAdmin(orderquantity.id,true).subscribe(data=>{
     if(data["errorMessage"]!=undefined){
       this.errorMessage=data["errorMessage"]
     }
     else
     {
       this.status=data
     }
   });
    this.router.navigateByUrl('/admin/merchant', { skipLocationChange: true }).then(() => {
      this.router.navigate(['/admin/order']);
    });
  }

  reject(orderquantity:OrderQuantityProduct) {
    console.log(orderquantity.id)

    this.service.updateProductStatusByAdmin(orderquantity.id,false).subscribe(data=>{
      if(data["errorMessage"]!=undefined){
        this.errorMessage=data["errorMessage"]
      }
      else
      {
        this.status=data
      }
    });
    this.router.navigateByUrl('/admin/merchant', { skipLocationChange: true }).then(() => {
      this.router.navigate(['/admin/order']);
    });
  }
}

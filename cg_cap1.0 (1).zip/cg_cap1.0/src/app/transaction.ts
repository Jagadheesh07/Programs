import { Order } from './order';

export class Transaction
{
    transactionId:number
    transactionType:string
    transactionDate:string
    transactionTime:string
    transactionAmount:number
    transactionStatus:string
    order:Order
}
import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
import { CreateAccountComponent } from './create-account/create-account.component';
import { componentFactoryName } from '../../node_modules/@angular/compiler';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';


const routes:Routes=[
  {
    path:'app-createAccount',
    component:CreateAccountComponent
    },
    {
      path:'app-showBalance',
      component:ShowBalanceComponent
    },
    {
      path:'app-deposit',
      component:DepositComponent
    },
    {
      path:'app-withdraw',
      component:WithdrawComponent
    },
   
    {
      path:'app-fundTransfer',
      component:FundTransferComponent
    },
    {
      path:'app-printTransaction',
      component:PrintTransactionComponent
    },
];


@NgModule({
  imports: [RouterModule.forRoot(routes),

    CommonModule
  ],
  exports:[RouterModule],
  
  declarations: []
})
export class AppRoutingModule { }

package com.cap.title;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class JobTitle_StepDefinition {
	
	WebDriver driver;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\mytsadas\\Desktop\\chrome driver\\chromedriver.exe");

		driver = new ChromeDriver();
	}
	
	@After
	public void quitt() {
		driver.quit();
	}
	
	@Given("^user is on Registartion Form$")
	public void user_is_on_Registartion_Form() throws Throwable {
		driver.get("C:\\Users\\mytsadas\\Desktop\\Module4\\Testing\\JobPortal_46005079\\html\\RegistrationForm.html");
	}

	@When("^user enters the html page$")
	public void user_enters_the_html_page() throws Throwable {
		Thread.sleep(1000);
	}

	@Then("^displays 'Welcome to JobsWorld'$")
	public void displays_Welcome_to_JobsWorld() throws Throwable {
		String expectedMessage = "Welcome to JobsWorld";
		String title=driver.getTitle();
		Assert.assertEquals(expectedMessage, title);
	}

}

package com.cap.regiatrationpagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Registration_PageFactory {
	
	WebDriver driver;
	
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	
	@FindBy(id="usrID")
	@CacheLookup
	WebElement userId;
	
	public WebElement getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}

	@FindBy(id="pwd")
	@CacheLookup
	WebElement password;
	
	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	@FindBy(id="usrname")
	@CacheLookup
	WebElement userName;
	
	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	
	@FindBy(id="addr")
	@CacheLookup
	WebElement address;
	
	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	@FindBy(name="country")
	@CacheLookup
	WebElement country;
	
	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	@FindBy(name="zip")
	@CacheLookup
	WebElement zipCode;
	
	public WebElement getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode.sendKeys(zipCode);
	}

	@FindBy(name="email")
	@CacheLookup
	WebElement email;
	
	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	@FindBy(name="sex")
	@CacheLookup
	WebElement gender;
	
	public WebElement getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender.click();
	}

	@FindBy(name="en")
	@CacheLookup
	WebElement language;
	
	public WebElement getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language.sendKeys(language);
	}
	
	@FindBy(id="desc")
	@CacheLookup
	WebElement about;

	public WebElement getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about.sendKeys(about);
	}

	@FindBy(name="submit")
	@CacheLookup
	WebElement submitButton;
	
	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton() {
		this.submitButton.click();
	}

	
	
	public Registration_PageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}

	
	
}

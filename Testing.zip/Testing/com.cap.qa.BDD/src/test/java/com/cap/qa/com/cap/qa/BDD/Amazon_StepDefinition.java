package com.cap.qa.com.cap.qa.BDD;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Amazon_StepDefinition {
	
		WebDriver Driver;
		
	@Given("^the user is on th amazon home page$")
	public void the_user_is_on_th_amazon_home_page(){
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\mytsadas\\Desktop\\chrome driver\\chromedriver.exe");
        Driver = new ChromeDriver();
        Driver.get("https://www.amazon.in/");
	}

	@Then("^select the category as Books$")
	public void select_the_category_as_Books(){
		WebElement Ele = Driver.findElement(By.xpath("//select[@id='searchDropdownBox']"));
        Select Select_Category = new Select(Ele);
        Select_Category.selectByIndex(11);
	}

	@Then("^user should enter Da vinci code in the search textbox$")
	public void user_should_enter_Da_vinci_code_in_the_search_textbox(){
		String Search_term = "Da Vinci Code";
        Driver.findElement(By.id("twotabsearchtextbox")).sendKeys(Search_term);
	}

	@Then("^the user click on magnifier button$")
	public void the_user_click_on_magnifier_button(){
		Driver.findElement(By.xpath("//input[@tabindex = '10']")).click();
	}

	@Then("^get the title of the books and print$")
	public void get_the_title_of_the_books_and_print(){
		List<WebElement> Titles = Driver.findElements(By.xpath("//span[@class = 'a-size-medium a-color-base a-text-normal']"));
        
        for(WebElement ttl : Titles) {
            System.out.println(ttl.getText());
        }
        
        Driver.close();
    }
}

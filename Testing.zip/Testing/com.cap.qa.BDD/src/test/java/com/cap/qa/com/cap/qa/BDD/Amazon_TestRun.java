package com.cap.qa.com.cap.qa.BDD;



import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
	features= {"C:\\Users\\mytsadas\\Desktop\\Module4\\Testing\\com.cap.qa.BDD\\src\\test\\resource\\Features\\Amazon_features.feature"},
	glue= {"com.cap.qa.com.cap.qa.BDD"},
	dryRun=false,
	strict=true,
	monochrome=true
)
public class Amazon_TestRun {

}

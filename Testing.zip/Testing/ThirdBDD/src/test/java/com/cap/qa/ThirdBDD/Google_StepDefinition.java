package com.cap.qa.ThirdBDD;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Google_StepDefinition {
	
	WebDriver Driver;
	String Search_term ;
	
	@Given("^the user on google search page$")
	public void the_user_on_google_search_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\mytsadas\\Desktop\\chrome driver\\chromedriver.exe");
		Driver=new ChromeDriver();
	    Driver.get("https://www.google.com/");
	}

	@Then("^user should enter the Automation Testing$")
	public void user_should_enter_the_Automation_Testing() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Search_term= "Automation Testing";
		Driver.findElement(By.xpath("//input[@title = 'Search']")).sendKeys(Search_term);
	    
	}

	@Then("^the user click on the serach button$")
	public void the_user_click_on_the_serach_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Driver.findElement(By.xpath("//input[@title = 'Search']")).submit();
	    
	}

	@Then("^get the keywords and print$")
	public void get_the_keywords_and_print() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String title = Driver.getTitle();
		if(title.contains(Search_term)) {
            System.out.println("Title is same");
           
        }else
        {
            System.out.println("Title is not same");
        }
		Driver.close();
	}
}

package com.cap.qa.ThirdBDD;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
	features= {"C:\\Users\\mytsadas\\Desktop\\Module4\\Testing\\ThirdBDD\\src\\test\\resource\\Features\\Google_features.feature"},
	glue= {"com.cap.qa.ThirdBDD"},
	dryRun=false,
	strict=true,
	monochrome=true
)

public class Google_TestRun {

}

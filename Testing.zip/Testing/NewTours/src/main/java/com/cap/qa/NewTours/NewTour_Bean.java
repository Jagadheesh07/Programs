package com.cap.qa.NewTours;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewTour_Bean {
	
	WebDriver driver;
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement userName;
	
	@FindBy(name="password")
	@CacheLookup
	WebElement password;
	
	@FindBy(name="login")
	@CacheLookup
	WebElement login;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getLogin() {
		return login;
	}

	public void setLogin() {
		this.login.click();
	}

	public NewTour_Bean(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}

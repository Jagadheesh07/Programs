package com.cap.qa.NewTours;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class NewTours_StepDefinition {
	WebDriver Driver;
	String UserPass="mercury";

	@Given("^the user is on the newtours home page$")
	public void the_user_is_on_the_newtours_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\mytsadas\\Desktop\\chrome driver\\chromedriver.exe");
	        Driver = new ChromeDriver();
	        Driver.get("http://newtours.demoaut.com/"); 
	   
	}

	@Then("^the user should Enter Login Credential of Username & Password as \"([^\"]*)\"$")
	public void the_user_should_Enter_Login_Credential_of_Username_Password_as(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Driver.findElement(By.name("userName")).sendKeys(UserPass);
        Driver.findElement(By.name("password")).sendKeys(UserPass);
	}

	@Then("^the user should Click on Signin button$")
	public void the_user_should_Click_on_Signin_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Driver.findElement(By.name("login")).click();
	}

	@Then("^get the passengers count as \"([^\"]*)\" using select object by index$")
	public void get_the_passengers_count_as_using_select_object_by_index(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 //passengers count
        WebElement ele=Driver.findElement(By.name("passCount"));
        Select Select_Category = new Select(ele);
        Select_Category.selectByIndex(3);
	}

	@Then("^get the Departure location, Month & Date using select by Value$")
	public void get_the_Departure_location_Month_Date_using_select_by_Value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//department location
        WebElement ele1=Driver.findElement(By.name("fromPort"));
        Select Select_Category = new Select(ele1);
        Select_Category.selectByValue("London");
        //month
        WebElement ele2=Driver.findElement(By.name("fromMonth"));
        Select Select_Category1 = new Select(ele2);
        Select_Category1.selectByValue("5");
        //date
        WebElement ele3=Driver.findElement(By.name("fromDay"));
        Select Select_Category2 = new Select(ele3);
        Select_Category2.selectByValue("28");
	}

	@Then("^get the Arrival location, Month,& Date  using select by Visible Text$")
	public void get_the_Arrival_location_Month_Date_using_select_by_Visible_Text() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 //arrival location
        WebElement ele4=Driver.findElement(By.name("toPort"));
        Select Select_Category = new Select(ele4);
        Select_Category.selectByValue("Paris");
        //month
        WebElement ele5=Driver.findElement(By.name("toMonth"));
        Select Select_Category1 = new Select(ele5);
        Select_Category1.selectByValue("6");
        //date
        WebElement ele6=Driver.findElement(By.name("toDay"));
        Select Select_Category2 = new Select(ele6);
        Select_Category2.selectByValue("28");
	}

	@Then("^the user should Click on Continue booking the flight ticket\\.$")
	public void the_user_should_Click_on_Continue_booking_the_flight_ticket() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Driver.findElement(By.name("findFlights")).click();
	}
}

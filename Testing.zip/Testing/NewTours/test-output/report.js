$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/mytsadas/Desktop/Module4/Testing/NewTours/src/test/resource/Features/NewTours_features.feature");
formatter.feature({
  "line": 1,
  "name": "Validate the newtours application to book a flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 12,
  "name": "Search as Automation testing and book the flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 16,
  "name": "The user must be in registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 18
    },
    {
      "cells": [
        "2"
      ],
      "line": 19
    },
    {
      "cells": [
        "3"
      ],
      "line": 20
    },
    {
      "cells": [
        "4"
      ],
      "line": 21
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "get the \"\u003cDeparture\u003e\" and \"\u003cArrival\u003e\" location",
  "keyword": "Then "
});
formatter.step({
  "line": 23,
  "name": "the user should Click on Continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.examples({
  "line": 27,
  "name": "",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;",
  "rows": [
    {
      "cells": [
        "Departure",
        "Arrival"
      ],
      "line": 28,
      "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;1"
    },
    {
      "cells": [
        "London",
        "Paris"
      ],
      "line": 29,
      "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;2"
    },
    {
      "cells": [
        "Paris",
        "London"
      ],
      "line": 30,
      "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;3"
    },
    {
      "cells": [
        "New York",
        "Paris"
      ],
      "line": 31,
      "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;4"
    },
    {
      "cells": [
        "London",
        "Zurich"
      ],
      "line": 32,
      "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;5"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 5,
  "name": "The user must be in login page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "the user is on the newtours home page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "the user should Enter Login Credential of \"mercury\" \u0026 \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_is_on_the_newtours_home_page()"
});
formatter.result({
  "duration": 10201542400,
  "status": "passed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_should_Click_on_Signin_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 29,
  "name": "Search as Automation testing and book the flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 16,
  "name": "The user must be in registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 18
    },
    {
      "cells": [
        "2"
      ],
      "line": 19
    },
    {
      "cells": [
        "3"
      ],
      "line": 20
    },
    {
      "cells": [
        "4"
      ],
      "line": 21
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "get the \"London\" and \"Paris\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 23,
  "name": "the user should Click on Continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_should_Click_on_Continue_booking_the_flight_ticket()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "line": 5,
  "name": "The user must be in login page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "the user is on the newtours home page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "the user should Enter Login Credential of \"mercury\" \u0026 \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_is_on_the_newtours_home_page()"
});
formatter.result({
  "duration": 7408489900,
  "status": "passed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_should_Click_on_Signin_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 30,
  "name": "Search as Automation testing and book the flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 16,
  "name": "The user must be in registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 18
    },
    {
      "cells": [
        "2"
      ],
      "line": 19
    },
    {
      "cells": [
        "3"
      ],
      "line": 20
    },
    {
      "cells": [
        "4"
      ],
      "line": 21
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "get the \"Paris\" and \"London\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 23,
  "name": "the user should Click on Continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_should_Click_on_Continue_booking_the_flight_ticket()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "line": 5,
  "name": "The user must be in login page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "the user is on the newtours home page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "the user should Enter Login Credential of \"mercury\" \u0026 \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_is_on_the_newtours_home_page()"
});
formatter.result({
  "duration": 6929420400,
  "status": "passed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_should_Click_on_Signin_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 31,
  "name": "Search as Automation testing and book the flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 16,
  "name": "The user must be in registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 18
    },
    {
      "cells": [
        "2"
      ],
      "line": 19
    },
    {
      "cells": [
        "3"
      ],
      "line": 20
    },
    {
      "cells": [
        "4"
      ],
      "line": 21
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "get the \"New York\" and \"Paris\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 23,
  "name": "the user should Click on Continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_should_Click_on_Continue_booking_the_flight_ticket()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "line": 5,
  "name": "The user must be in login page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "the user is on the newtours home page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "the user should Enter Login Credential of \"mercury\" \u0026 \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_is_on_the_newtours_home_page()"
});
formatter.result({
  "duration": 12651368000,
  "status": "passed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_should_Click_on_Signin_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 32,
  "name": "Search as Automation testing and book the flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;5",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 16,
  "name": "The user must be in registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 18
    },
    {
      "cells": [
        "2"
      ],
      "line": 19
    },
    {
      "cells": [
        "3"
      ],
      "line": 20
    },
    {
      "cells": [
        "4"
      ],
      "line": 21
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "get the \"London\" and \"Zurich\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 23,
  "name": "the user should Click on Continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({
  "location": "NewTours_StepDefinition.the_user_should_Click_on_Continue_booking_the_flight_ticket()"
});
formatter.result({
  "status": "skipped"
});
});
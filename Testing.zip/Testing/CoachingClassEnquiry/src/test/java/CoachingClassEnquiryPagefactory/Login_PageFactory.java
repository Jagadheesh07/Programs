package CoachingClassEnquiryPagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login_PageFactory {
	
	WebDriver driver;
	
	@FindBy(id="fname")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(id="Submit1")
	@CacheLookup
	WebElement submitRequest;

	
	
	public WebDriver getDriver() {
		return driver;
	}
	
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	
	
	
	public void setSubmitRequest() {
		this.submitRequest.click();
	}

	public WebElement getSubmitRequest() {
		return submitRequest;
	}

	public WebElement getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	
	

	
	
	public Login_PageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	

}

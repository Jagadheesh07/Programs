package CoachingClassEnquiryTitle;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Title_StepDefinition {
	
	/*WebDriver driver;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\mytsadas\\Desktop\\chrome driver\\chromedriver.exe");

		driver = new ChromeDriver();
	}
	
	@After
	public void quitt() {
		driver.quit();
	}
	@Given("^user on the coaching class enquiry page$")
	public void user_on_the_coaching_class_enquiry_page() throws Throwable {
	driver.get("C:\\Users\\mytsadas\\Downloads\\Module 4\\Sagarika Kanikella - 190117 - CoachingClassEnquiry\\CochingClassEnquiry\\html\\Coaching_Class_Enquiry.html");
	}

	@When("^wait to load the web page$")
	public void wait_to_load_the_web_page() throws Throwable {
		Thread.sleep(15000);

	}

	@Then("^check the title as Online Coaching Class Enquiry Form$")
	public void check_the_title_as_Online_Coaching_Class_Enquiry_Form() throws Throwable {
		String title=driver.getTitle();
		Assert.assertEquals("Online Coaching Class Enquiry Form",title);
	}

	@Then("^check the text as Tuition Enquiry Details Form$")
	public void check_the_text_as_Tuition_Enquiry_Details_Form() throws Throwable {
		String text=driver.findElement(By.className("auto-style7")).getText();
		Assert.assertEquals("Tuition Enquiry Details Form",text);
		
	}*/

}

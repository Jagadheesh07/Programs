package CoachingClassEnquiryTitle;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"C:\\Users\\mytsadas\\Desktop\\Module4\\Testing\\CoachingClassEnquiry\\src\\test\\resource\\Feature\\Title_features.feature"}, 
		glue = "CoachingClassEnquiryTitle",
		dryRun=false,
		strict=true,
		monochrome=false
		)

public class Tittle_TestRun {

}

package CoachingClassEnquiryLogin;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"C:\\Users\\mytsadas\\Desktop\\Module4\\Testing\\CoachingClassEnquiry\\src\\test\\resource\\Feature\\Login_features.feature"}, 
		glue = "CoachingClassEnquiryLogin",
		dryRun=false,
		strict=true,
		monochrome=false)

public class Login_TestRun {

}

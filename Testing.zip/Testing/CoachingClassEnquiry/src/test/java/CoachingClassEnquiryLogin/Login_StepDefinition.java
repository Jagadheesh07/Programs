package CoachingClassEnquiryLogin;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import CoachingClassEnquiryPagefactory.Login_PageFactory;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Login_StepDefinition {
	
	WebDriver driver;
	Login_PageFactory pageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\mytsadas\\Desktop\\chrome driver\\chromedriver.exe");

		driver = new ChromeDriver();
	}
	
	@After
	public void quitt() {
		driver.quit();
	}
	
	@Given("^the user on coaching class enquiry page$")
	public void the_user_on_coaching_class_enquiry_page() throws Throwable {
		driver.get("C:\\Users\\mytsadas\\Downloads\\Module 4\\Sagarika Kanikella - 190117 - CoachingClassEnquiry\\CochingClassEnquiry\\html\\Coaching_Class_Enquiry.html");  
	}

	@Then("^enter the first name$")
	public void enter_the_first_name() throws Throwable {
	    pageFactory.setFirstName("Mythili");
	    Thread.sleep(1000);
	}

	@Then("^check if the name textbox is empty$")
	public void check_if_the_name_textbox_is_empty() throws Throwable {
	    pageFactory.setFirstName("");
	    pageFactory.setSubmitRequest();
	    Thread.sleep(1000);
	}

	@Then("^display the error meesage as Enter the first name$")
	public void display_the_error_meesage_as_Enter_the_first_name() throws Throwable {
	    String expect="First Name must be filled out";
	    String actual1=driver.switchTo().alert().getText();
	    driver.switchTo().alert().accept();
	    Assert.assertEquals(expect, actual1);
	}

}

package com.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Trans")
public class BankTransactions {
	 @Id
	@GeneratedValue
	private long transId;
	private long fromAcc;
	private long toAcc;
	private long transOldBal;
	private long transNewBal;
	private String transType;
	private long accNum;
	
	//setter and getters
		
	public long getTransId() {
		return transId;
	}
	public void setTransId(long transId) {
		this.transId = transId;
	}
	public long getFromAcc() {
		return fromAcc;
	}
	public void setFromAcc(long fromAcc) {
		this.fromAcc = fromAcc;
	}
	public long getToAcc() {
		return toAcc;
	}
	public void setToAcc(long toAcc) {
		this.toAcc = toAcc;
	}
	public long getTransOldBal() {
		return transOldBal;
	}
	public void setTransOldBal(long transOldBal) {
		this.transOldBal = transOldBal;
	}
	public long getTransNewBal() {
		return transNewBal;
	}
	public void setTransNewBal(long transNewBal) {
		this.transNewBal = transNewBal;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	@Override
	public String toString() {
		
		return (transId+"                "+fromAcc + "               "+ toAcc +"           "+transOldBal +"            "+transNewBal +"           "+transType );
	}
	

}

package com.bank.dao;

import java.util.List;

import com.bank.bean.BankDetails;
import com.bank.bean.BankTransactions;


public interface BankDao 
{
	long createAccount(BankDetails bankdetails);
	BankDetails showDetails(long accNum);
	long depositDetails(long accNum,long depAcc);
	long withdrawDetails(long accNum,long withDraw);
	long fundTransfer(long accNum4,long accNum5,long fundTrans);
	 List<BankTransactions> printTransactions();
	
	
}

package com.bank.dao;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.bank.bean.BankDetails;
import com.bank.bean.BankTransactions;

public class BankDaoImp1Test
{
	//positive response
	BankDaoImp1 dao=new BankDaoImp1();
	@Test
	public void retrive()
	{
		BankDetails bank=new BankDetails();
		bank.setAccBal(200);
		bank.setAccNum(1);
		bank.setAccType("current");
		bank.setCustMobNum(8974563254l);
		bank.setCustName("Mala");
		BankDetails AccNum=dao.showDetails(1);
		System.out.println(AccNum.getAccBal());
		Assert.assertEquals(240,AccNum.getAccBal());
	}
	//positive response
	@Test
	public void depo()
	{
		BankTransactions bt=new BankTransactions();
		bt.setAccNum(1);
		bt.setTransId(25);
		bt.setTransOldBal(200);
		bt.setTransNewBal(240);
		long AccNum=dao.depositDetails(1, 40);
		Assert.assertEquals(240,AccNum);
	}
	//positive response
	@Test
	public void With()
	{
		BankTransactions bt=new BankTransactions();
		bt.setAccNum(1);
		bt.setTransId(25);
		bt.setTransOldBal(200);
		bt.setTransNewBal(240);
		long AccNum=dao.withdrawDetails(1,40);
		Assert.assertEquals(240, AccNum);
	}
	//Another method of junit for deposit(positive respones)
	@Test
    public void test() {
        int balance=1000;
        int result=balance+800;
        int expectedResult=1800;
        assertEquals(expectedResult,result);
        System.out.println(expectedResult=result);
    }
	//Another method of junit for deposit(negative respones)
    @Test
    public void test1()
    {
        int balance2=1000;
        int result2=balance2+800;
        int expectedResult2=2800;
        assertEquals(expectedResult2,result2);
        System.out.println(expectedResult2=result2);
    }
	
}

package com.bank.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bank.bean.BankDetails;
import com.bank.bean.BankTransactions;
import com.bank.execptions.AccountNumberNotFoundException;
import com.bank.service.BankService;
import com.bank.service.BankServiceImp1;

public class BankMainui {

	static ApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
	static BankService service1 = ctx.getBean("service", BankServiceImp1.class);
	
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		while (true) {
			String option = null;
			System.out.println("Welcome to Bank payment Wallet");
			System.out.println("******************************");
			System.out.println("Select any one option from the required option:");
			System.out.println("-----------------------------------------------");
			System.out.println(
					"1.Create Account\n2.Deposit\n3.Withdraw\n4.Fund Transfer\n5.Show Balance\n6.Print Transaction\n7.Exit");
			// option = scanner.nextInt();
			try {
				option = scanner.next();
			} catch (Exception ae) {
				System.err.println("Please Enter from the above numbers Only " + ae);
			}
			switch (option) {
			case "1":// Create Account
				String custName;
				// String accType = null;
				long custMobNum;
				boolean isName = false;
				boolean isNum = false;
				boolean isAccType = false;
				// validation for name
				do {
					System.out.println("Enter your name: ");
					custName = scanner.next();
					isName = service1.validateName(custName);

					if (!isName) {
						System.out.println("Please enter first letter of name in Capital Alphabet: ");
					}
				} while (!isName);

				// validation for mobile number
				do {
					System.out.println("Enter you mobile number: ");
					custMobNum = scanner.nextLong();
					isNum = service1.validateMobNum(custMobNum);

					if (!isNum) {
						System.out.println(
								"Please Enter vaild phone number starting from 6 or 7 or 8 or 9 and having 10 digits.");
					}
				} while (!isNum);
				String accType1;
				// validation for Account Type
				do {
					System.out.println("Enter the type of your account: ");
					accType1 = scanner.next();
					isAccType = service1.validateAccType(accType1);

					if (isAccType) {
						System.out.println("Please Enter savings or current.");
					}
				} while (isAccType);

				System.out.println("Enter the first minimum balance: ");
				long accBal = scanner.nextLong();
				System.out.println("Enter the branch: ");
				String custBranch = scanner.next();
				BankDetails bankdetails = new BankDetails();
				bankdetails.setCustName(custName);
				bankdetails.setCustMobNum(custMobNum);
				bankdetails.setAccType(accType1);
				bankdetails.setAccBal(accBal);
				bankdetails.setCustBranch(custBranch);
				long accNum = service1.createAccount(bankdetails);// Sending and
																	// retrieving
																	// values to
																	// service
																	// layer
				System.out.println("Your Account Number is: " + accNum);
				System.out.println("-----Account Created Successfully------");
				System.out.println("Thank you for your service");
				System.out.println("\n\n");
				break;
			case "2":// Deposit Amount
				System.out.println("******Deposit******");
				System.out.println("-------------------");
				try {
					System.out.println("Enter your Account number: ");
					long accNum2 = scanner.nextLong();
					System.out.println("Enter the amount for Deposit: ");
					long depAcc = scanner.nextLong();
					long depdet = service1.depositDetails(accNum2, depAcc);// Sending
																			// and
																			// retrieving
																			// values
																			// to
																			// service
																			// layer
					System.out.println("Your Balance after depositing is: " + depdet);
					System.out.println("Thank you for your service");
					System.out.println("\n\n");
				} catch (AccountNumberNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (InputMismatchException e) {
					System.out.println("Enter Account Number, Please dont enter String");
				}

				break;
			case "3":// Withdraw Amount
				System.out.println("******Withdraw******");
				System.out.println("---------------------");
				try {
					System.out.println("Enter your Account number: ");
					long accNum3 = scanner.nextLong();
					System.out.println("Enter the amount for Withdrawing: ");
					long withDraw = scanner.nextLong();
					long witdraw = service1.withdrawDetails(accNum3, withDraw);// Sending
																				// and
																				// retrieving
																				// values
																				// to
																				// service
																				// layer
					System.out.println("Your Balance after withdrawing is: " + witdraw);
					System.out.println("Thank you for your service");
					System.out.println("\n\n");
				} catch (AccountNumberNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (InputMismatchException e) {
					System.out.println("Enter Account Number, Please dont enter String");
				}
				break;

			case "4":// Fund Transfer
				System.out.println("******Fund Transfer******");
				System.out.println("--------------------------");
				try {
					System.out.println("Enter your Account Number: ");
					long accNum4 = scanner.nextLong();
					System.out.println("Enter the Account Number of the person whom you want to tranfer money to: ");
					long accNum5 = scanner.nextLong();
					System.out.println("Enter the Amount, How much you want to transfer: ");
					long fundTrans = scanner.nextLong();

					long funTrans = service1.fundTransfer(accNum4, accNum5, fundTrans);// Sending
																						// and
																						// retrieving
																						// values
																						// to
																						// service
																						// layer
					System.out.println("Your Balance after transferring amount is: " + funTrans);
					System.out.println("Thank you for service");
					System.out.println("\n\n");

				} catch (AccountNumberNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (InputMismatchException e) {
					System.out.println("Enter Account Number, Please dont enter String");
				}
				break;
			case "5":// Show All the Details
				System.out.println("******Show Details******");
				System.out.println("------------------------");
				try {
					System.out.println("Please enter your Account number to provide you with your details: ");
					long accNum1 = scanner.nextLong();

					BankDetails baldet = service1.showDetails(accNum1);// Sending
																		// and
																		// retrieving
																		// values
																		// to
																		// service
																		// layer
					System.out.println("Your Current Balance is: " + baldet.getAccBal());
					System.out.println("\n\n");
				} catch (AccountNumberNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (InputMismatchException e) {
					System.out.println("Enter Account Number, Please dont enter String");
				}
				break;

			case "6":// Print All the Transactions
				System.out.println("******Print Transactions******");
				System.out.println(
						"******************************************************************************************************************************");
				System.out.println("Transaction Id" + "    " + "From Account" + "    " + "To Account" + "    "
						+ "Old Balance" + "    " + "New Balance" + "     " + "Transaction Type");
				System.out.println(
						"******************************************************************************************************************************");
				service1.printTransactions();

				List<BankTransactions> result = service1.printTransactions();// Sending
																				// and
																				// retrieving
																				// values
																				// to
																				// service
																				// layer
				ListIterator<BankTransactions> lis = result.listIterator();
				while (lis.hasNext()) // forward direction
				{
					System.out.println(lis.next() + " ");
				}
				System.out.println("\n\n");

				// System.out.println(transId+" "+fromAcc + " "+ toAcc +"
				// "+transOldBal +" "+transNewBal +" "+transType );

				break;

			case "7":
				System.out.println("Thank you for choosing our bank ");
				// break;
				System.exit(0);
			}
		}
	}
}

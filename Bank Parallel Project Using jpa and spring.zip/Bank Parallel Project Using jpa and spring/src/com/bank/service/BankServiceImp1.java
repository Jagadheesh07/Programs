package com.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.bean.BankDetails;
import com.bank.bean.BankTransactions;
import com.bank.dao.BankDao;


@Service("service")
public class BankServiceImp1 implements BankService {
	/*BankDetails bean = new BankDetails();
	BankDaoImp1 dao = new BankDaoImp1();
*/	
	private BankDao dao;
		
	public BankDao getDao() {
		return dao;
	}
	@Autowired
	public void setDao(BankDao dao) {
		this.dao = dao;
	}

	@Override
	public long createAccount(BankDetails bankdetails) {
		
		dao.createAccount(bankdetails);
		
		return bankdetails.getAccNum();
	}

	@Override
	public BankDetails showDetails(long accNum) {
		
		return dao.showDetails(accNum);
	}

	@Override
	public long depositDetails(long accNum, long depAcc) {
		
		long abc=dao.depositDetails(accNum, depAcc);
		
		return abc;
	}

	@Override
	public long withdrawDetails(long accNum, long withDraw) {
			 long with=dao.withdrawDetails(accNum, withDraw);
		
		return with;
	}

	@Override
	public long fundTransfer(long accNum4, long accNum5, long fundTrans) {
	
		long fundTrans1 = dao.fundTransfer(accNum4, accNum5, fundTrans);
		
		return fundTrans1;
	}

	@Override
	public  List<BankTransactions> printTransactions() { 
		// returns the list of transactions done
		return dao.printTransactions();
	}

	//Validation for name
	@Override
	public boolean validateName(String custName)
	{
		if(custName.matches("[A-Z][a-zA-Z]*"))
		{
			return true;
		}
		else
		{
			return false;
		}
	
	}

	//Validation for Mobile number
	@Override
	public boolean validateMobNum(long custMobNum) 
	{
		String mobN=Long.toString(custMobNum);
		if(mobN.matches("[6-9][0-9]{9}"))
		{
			return true;
		}
		else
		{
			return false;
		}
			
	}

	//Validation to check the type of account
	@Override
	public boolean validateAccType(String accType) 
	{
		
		if(accType.equalsIgnoreCase("savings") || accType.equalsIgnoreCase("current"))
		{
			return false;
		}
		else
		{
			return true;
		}
		
	}
}
